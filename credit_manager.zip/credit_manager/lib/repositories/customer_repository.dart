import '../core/database/database_helper.dart';
import '../models/customer.dart';

class CustomerRepository {
  final DatabaseHelper _dbHelper = DatabaseHelper.instance;

  Future<int> insertCustomer(Customer customer) async {
    final db = await _dbHelper.database;
    return await db.insert('customers', customer.toMap()..remove('id'));
  }

  Future<int> updateCustomer(Customer customer) async {
    final db = await _dbHelper.database;
    return await db.update(
      'customers',
      customer.toMap(),
      where: 'id = ?',
      whereArgs: [customer.id],
    );
  }

  Future<int> deleteCustomer(int id) async {
    final db = await _dbHelper.database;
    return await db.delete('customers', where: 'id = ?', whereArgs: [id]);
  }

  Future<Customer?> getCustomerById(int id) async {
    final db = await _dbHelper.database;
    final maps = await db.query('customers', where: 'id = ?', whereArgs: [id]);
    if (maps.isEmpty) return null;
    return Customer.fromMap(maps.first);
  }

  Future<List<Customer>> getAllCustomers() async {
    final db = await _dbHelper.database;
    final maps = await db.query('customers', orderBy: 'name COLLATE NOCASE ASC');
    return maps.map((m) => Customer.fromMap(m)).toList();
  }

  /// Search customers by partial name match (for smart search / suggestions)
  Future<List<Customer>> searchCustomers(String query) async {
    final db = await _dbHelper.database;
    final maps = await db.query(
      'customers',
      where: 'name LIKE ?',
      whereArgs: ['%$query%'],
      orderBy: 'name COLLATE NOCASE ASC',
    );
    return maps.map((m) => Customer.fromMap(m)).toList();
  }

  /// Get balance for a single customer: total purchases - total payments
  Future<CustomerWithBalance> getCustomerWithBalance(Customer customer) async {
    final db = await _dbHelper.database;

    final salesResult = await db.rawQuery(
      'SELECT COALESCE(SUM(total), 0) as total FROM sales WHERE customer_id = ? AND is_deleted = 0',
      [customer.id],
    );
    final paymentsResult = await db.rawQuery(
      'SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE customer_id = ? AND is_deleted = 0',
      [customer.id],
    );

    final totalPurchases = (salesResult.first['total'] as num).toDouble();
    final totalPayments = (paymentsResult.first['total'] as num).toDouble();

    return CustomerWithBalance(
      customer: customer,
      totalPurchases: totalPurchases,
      totalPayments: totalPayments,
    );
  }

  /// Get all customers with their computed balances
  Future<List<CustomerWithBalance>> getAllCustomersWithBalances() async {
    final customers = await getAllCustomers();
    final List<CustomerWithBalance> result = [];
    for (final c in customers) {
      result.add(await getCustomerWithBalance(c));
    }
    return result;
  }

  /// Top debtors sorted by balance descending
  Future<List<CustomerWithBalance>> getTopDebtors({int limit = 5}) async {
    final all = await getAllCustomersWithBalances();
    all.sort((a, b) => b.balance.compareTo(a.balance));
    return all.where((c) => c.balance > 0).take(limit).toList();
  }

  Future<double> getTotalDebts() async {
    final all = await getAllCustomersWithBalances();
    double total = 0;
    for (final c in all) {
      if (c.balance > 0) total += c.balance;
    }
    return total;
  }

  Future<int> getCustomerCount() async {
    final db = await _dbHelper.database;
    final result = await db.rawQuery('SELECT COUNT(*) as count FROM customers');
    return result.first['count'] as int;
  }

  /// Get the date of the last payment for a customer, or null if none
  Future<DateTime?> getLastPaymentDate(int customerId) async {
    final db = await _dbHelper.database;
    final result = await db.query(
      'payments',
      where: 'customer_id = ? AND is_deleted = 0',
      whereArgs: [customerId],
      orderBy: 'date DESC',
      limit: 1,
    );
    if (result.isEmpty) return null;
    return DateTime.parse(result.first['date'] as String);
  }

  /// Customers with balance > 0 who haven't paid in [days] days (or never have)
  Future<List<CustomerWithBalance>> getLatePaymentCustomers(int days) async {
    final all = await getAllCustomersWithBalances();
    final debtors = all.where((c) => c.balance > 0).toList();
    final cutoff = DateTime.now().subtract(Duration(days: days));

    final List<CustomerWithBalance> late = [];
    for (final c in debtors) {
      final lastPayment = await getLastPaymentDate(c.customer.id!);
      if (lastPayment == null || lastPayment.isBefore(cutoff)) {
        late.add(c);
      }
    }
    return late;
  }
}
