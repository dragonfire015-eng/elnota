import '../core/database/database_helper.dart';
import '../models/sale.dart';

class SaleRepository {
  final DatabaseHelper _dbHelper = DatabaseHelper.instance;

  Future<int> insertSale(Sale sale) async {
    final db = await _dbHelper.database;
    return await db.insert('sales', sale.toMap()..remove('id'));
  }

  Future<int> updateSale(Sale sale) async {
    final db = await _dbHelper.database;
    return await db.update(
      'sales',
      sale.toMap(),
      where: 'id = ?',
      whereArgs: [sale.id],
    );
  }

  /// Soft delete (allows restore)
  Future<int> softDeleteSale(int id) async {
    final db = await _dbHelper.database;
    return await db.update(
      'sales',
      {'is_deleted': 1},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> restoreSale(int id) async {
    final db = await _dbHelper.database;
    return await db.update(
      'sales',
      {'is_deleted': 0},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> permanentlyDeleteSale(int id) async {
    final db = await _dbHelper.database;
    return await db.delete('sales', where: 'id = ?', whereArgs: [id]);
  }

  Future<Sale?> getSaleById(int id) async {
    final db = await _dbHelper.database;
    final maps = await db.query('sales', where: 'id = ?', whereArgs: [id]);
    if (maps.isEmpty) return null;
    return Sale.fromMap(maps.first);
  }

  Future<List<Sale>> getSalesByCustomer(int customerId, {bool includeDeleted = false}) async {
    final db = await _dbHelper.database;
    final where = includeDeleted ? 'customer_id = ?' : 'customer_id = ? AND is_deleted = 0';
    final maps = await db.query(
      'sales',
      where: where,
      whereArgs: [customerId],
      orderBy: 'date DESC',
    );
    return maps.map((m) => Sale.fromMap(m)).toList();
  }

  Future<List<Sale>> getSalesByCustomerInRange(int customerId, DateTime start, DateTime end) async {
    final db = await _dbHelper.database;
    final maps = await db.query(
      'sales',
      where: 'customer_id = ? AND is_deleted = 0 AND date >= ? AND date <= ?',
      whereArgs: [customerId, start.toIso8601String(), end.toIso8601String()],
      orderBy: 'date DESC',
    );
    return maps.map((m) => Sale.fromMap(m)).toList();
  }

  Future<List<Sale>> getRecentSales({int limit = 10}) async {
    final db = await _dbHelper.database;
    final maps = await db.query(
      'sales',
      where: 'is_deleted = 0',
      orderBy: 'date DESC',
      limit: limit,
    );
    return maps.map((m) => Sale.fromMap(m)).toList();
  }

  /// Total sales for current month
  Future<double> getMonthSalesTotal() async {
    final db = await _dbHelper.database;
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, 1);
    final result = await db.rawQuery(
      'SELECT COALESCE(SUM(total), 0) as total FROM sales WHERE is_deleted = 0 AND date >= ?',
      [start.toIso8601String()],
    );
    return (result.first['total'] as num).toDouble();
  }
}
