import '../core/database/database_helper.dart';
import '../models/payment.dart';

class PaymentRepository {
  final DatabaseHelper _dbHelper = DatabaseHelper.instance;

  Future<int> insertPayment(Payment payment) async {
    final db = await _dbHelper.database;
    return await db.insert('payments', payment.toMap()..remove('id'));
  }

  Future<int> updatePayment(Payment payment) async {
    final db = await _dbHelper.database;
    return await db.update(
      'payments',
      payment.toMap(),
      where: 'id = ?',
      whereArgs: [payment.id],
    );
  }

  Future<int> softDeletePayment(int id) async {
    final db = await _dbHelper.database;
    return await db.update(
      'payments',
      {'is_deleted': 1},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> restorePayment(int id) async {
    final db = await _dbHelper.database;
    return await db.update(
      'payments',
      {'is_deleted': 0},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> permanentlyDeletePayment(int id) async {
    final db = await _dbHelper.database;
    return await db.delete('payments', where: 'id = ?', whereArgs: [id]);
  }

  Future<Payment?> getPaymentById(int id) async {
    final db = await _dbHelper.database;
    final maps = await db.query('payments', where: 'id = ?', whereArgs: [id]);
    if (maps.isEmpty) return null;
    return Payment.fromMap(maps.first);
  }

  Future<List<Payment>> getPaymentsByCustomer(int customerId, {bool includeDeleted = false}) async {
    final db = await _dbHelper.database;
    final where = includeDeleted ? 'customer_id = ?' : 'customer_id = ? AND is_deleted = 0';
    final maps = await db.query(
      'payments',
      where: where,
      whereArgs: [customerId],
      orderBy: 'date DESC',
    );
    return maps.map((m) => Payment.fromMap(m)).toList();
  }

  Future<List<Payment>> getPaymentsByCustomerInRange(int customerId, DateTime start, DateTime end) async {
    final db = await _dbHelper.database;
    final maps = await db.query(
      'payments',
      where: 'customer_id = ? AND is_deleted = 0 AND date >= ? AND date <= ?',
      whereArgs: [customerId, start.toIso8601String(), end.toIso8601String()],
      orderBy: 'date DESC',
    );
    return maps.map((m) => Payment.fromMap(m)).toList();
  }

  Future<List<Payment>> getRecentPayments({int limit = 10}) async {
    final db = await _dbHelper.database;
    final maps = await db.query(
      'payments',
      where: 'is_deleted = 0',
      orderBy: 'date DESC',
      limit: limit,
    );
    return maps.map((m) => Payment.fromMap(m)).toList();
  }

  /// Total payments for current month
  Future<double> getMonthPaymentsTotal() async {
    final db = await _dbHelper.database;
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, 1);
    final result = await db.rawQuery(
      'SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE is_deleted = 0 AND date >= ?',
      [start.toIso8601String()],
    );
    return (result.first['total'] as num).toDouble();
  }
}
