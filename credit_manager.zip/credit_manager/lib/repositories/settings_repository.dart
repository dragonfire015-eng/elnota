import 'package:sqflite/sqflite.dart';
import '../core/database/database_helper.dart';

class SettingsRepository {
  final DatabaseHelper _dbHelper = DatabaseHelper.instance;

  Future<String?> getValue(String key) async {
    final db = await _dbHelper.database;
    final result = await db.query('settings', where: 'key = ?', whereArgs: [key]);
    if (result.isEmpty) return null;
    return result.first['value'] as String?;
  }

  Future<void> setValue(String key, String value) async {
    final db = await _dbHelper.database;
    await db.insert(
      'settings',
      {'key': key, 'value': value},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<double> getDebtAlertThreshold() async {
    final v = await getValue('debt_alert_threshold');
    return double.tryParse(v ?? '500') ?? 500;
  }

  Future<int> getLatePaymentDays() async {
    final v = await getValue('late_payment_days');
    return int.tryParse(v ?? '30') ?? 30;
  }

  Future<bool> getDarkMode() async {
    final v = await getValue('dark_mode');
    return v == '1';
  }

  Future<String> getShopName() async {
    return await getValue('shop_name') ?? 'محلي';
  }
}
