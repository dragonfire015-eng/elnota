import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:share_plus/share_plus.dart';

import '../core/database/database_helper.dart';

class BackupService {
  /// Export the current database to a backup file in the device's
  /// documents directory and return its path.
  static Future<String> exportBackup() async {
    final dbPath = await DatabaseHelper.instance.getDatabasePath();
    final dbFile = File(dbPath);

    if (!await dbFile.exists()) {
      throw Exception('قاعدة البيانات غير موجودة');
    }

    final docsDir = await getApplicationDocumentsDirectory();
    final backupsDir = Directory('${docsDir.path}/backups');
    if (!await backupsDir.exists()) {
      await backupsDir.create(recursive: true);
    }

    final timestamp = DateTime.now().toIso8601String().replaceAll(':', '-').split('.').first;
    final backupPath = '${backupsDir.path}/backup_$timestamp.db';

    await dbFile.copy(backupPath);
    return backupPath;
  }

  /// Share any file (PDF, backup, etc.) via system share sheet
  static Future<void> shareFile(String path, {String? text}) async {
    await Share.shareXFiles([XFile(path)], text: text);
  }

  /// Share the backup file (e.g. via WhatsApp, Drive, etc.)
  static Future<void> shareBackup(String path) async {
    await Share.shareXFiles([XFile(path)], text: 'نسخة احتياطية - تطبيق إدارة الديون');
  }

  /// Let user pick a backup file and restore it.
  /// Closes the current DB connection, replaces the file, then the app
  /// must be restarted (or DatabaseHelper re-initialized) to use the new data.
  static Future<bool> importBackup() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.any,
    );

    if (result == null || result.files.single.path == null) {
      return false;
    }

    final pickedPath = result.files.single.path!;
    final pickedFile = File(pickedPath);

    if (!await pickedFile.exists()) {
      throw Exception('الملف المحدد غير موجود');
    }

    // Close current DB connection before overwriting
    await DatabaseHelper.instance.close();

    final dbPath = await DatabaseHelper.instance.getDatabasePath();
    await pickedFile.copy(dbPath);

    // Re-open with fresh connection
    await DatabaseHelper.instance.database;

    return true;
  }

  /// Get list of all local backups
  static Future<List<FileSystemEntity>> listBackups() async {
    final docsDir = await getApplicationDocumentsDirectory();
    final backupsDir = Directory('${docsDir.path}/backups');
    if (!await backupsDir.exists()) return [];

    final files = backupsDir.listSync()
      ..sort((a, b) => b.statSync().modified.compareTo(a.statSync().modified));
    return files;
  }
}
