import '../models/customer.dart';
import '../models/product.dart';

enum VoiceCommandType { sale, payment, unknown }

/// Result of parsing a voice command
class VoiceCommandResult {
  final VoiceCommandType type;
  final String rawText;

  // For sale
  final Customer? customer;
  final List<Customer>? ambiguousCustomers; // if multiple matches
  final Product? product;
  final double quantity;

  // For payment
  final double? paymentAmount;

  final String? error;

  VoiceCommandResult({
    required this.type,
    required this.rawText,
    this.customer,
    this.ambiguousCustomers,
    this.product,
    this.quantity = 1,
    this.paymentAmount,
    this.error,
  });

  bool get isValid => error == null && customer != null;
}

/// Parses Arabic voice commands like:
/// "أحمد أخذ علبة سجائر"
/// "أحمد أخذ علبتين سجائر"
/// "محمد أخذ 3 شيبسي"
/// "أحمد دفع 100 جنيه"
/// "محمد دفع 250"
class VoiceCommandParser {
  // Words that indicate a "take/sale" action
  static const List<String> _saleVerbs = [
    'اخذ', 'أخذ', 'خد', 'أخد', 'اشترى', 'إشترى', 'جاب', 'أكل', 'شرب', 'حساب'
  ];

  // Words that indicate a "payment" action
  static const List<String> _paymentVerbs = [
    'دفع', 'سدد', 'سداد', 'دفعة', 'دفعه', 'حول', 'حوالة', 'وصل'
  ];

  // Currency words to strip
  static const List<String> _currencyWords = ['جنيه', 'جنية', 'جنيهات', 'ج', 'جني', 'pound', 'le'];

  // Arabic word numbers -> digit
  static const Map<String, double> _wordNumbers = {
    'واحد': 1, 'واحدة': 1, 'وحدة': 1,
    'اثنين': 2, 'إثنين': 2, 'اتنين': 2, 'تنين': 2,
    'ثلاثة': 3, 'تلاتة': 3, 'ثلاث': 3,
    'اربعة': 4, 'أربعة': 4, 'اربع': 4,
    'خمسة': 5, 'خمس': 5,
    'ستة': 6, 'ست': 6,
    'سبعة': 7, 'سبع': 7,
    'ثمانية': 8, 'ثمان': 8, 'تمانية': 8,
    'تسعة': 9, 'تسع': 9,
    'عشرة': 10, 'عشر': 10,
  };

  // Dual suffix forms that imply quantity = 2 (e.g. "علبتين" = two boxes, "كولتين" = two colas)
  // We detect this by suffix "ين" or "تين" on a product-like word.

  /// Main entry point: parse [text] given known [customers] and [products].
  static VoiceCommandResult parse(
    String text,
    List<Customer> customers,
    List<Product> products,
  ) {
    final normalized = _normalize(text);
    if (normalized.isEmpty) {
      return VoiceCommandResult(
        type: VoiceCommandType.unknown,
        rawText: text,
        error: 'لم يتم التعرف على أي نص',
      );
    }

    final words = normalized.split(' ').where((w) => w.isNotEmpty).toList();

    // Determine command type by searching for verbs
    int verbIndex = -1;
    VoiceCommandType type = VoiceCommandType.unknown;

    for (int i = 0; i < words.length; i++) {
      if (_paymentVerbs.contains(words[i])) {
        type = VoiceCommandType.payment;
        verbIndex = i;
        break;
      }
    }
    if (type == VoiceCommandType.unknown) {
      for (int i = 0; i < words.length; i++) {
        if (_saleVerbs.contains(words[i])) {
          type = VoiceCommandType.sale;
          verbIndex = i;
          break;
        }
      }
    }

    if (type == VoiceCommandType.unknown || verbIndex == -1) {
      return VoiceCommandResult(
        type: VoiceCommandType.unknown,
        rawText: text,
        error: 'لم يتم التعرف على نوع العملية (بيع أو دفع)',
      );
    }

    // Customer name is assumed to be everything before the verb
    final nameWords = words.sublist(0, verbIndex);
    if (nameWords.isEmpty) {
      return VoiceCommandResult(
        type: type,
        rawText: text,
        error: 'لم يتم التعرف على اسم العميل',
      );
    }

    final matchedCustomers = _matchCustomer(nameWords.join(' '), customers);

    if (type == VoiceCommandType.payment) {
      // Everything after the verb should contain the amount
      final rest = words.sublist(verbIndex + 1);
      final amount = _extractAmount(rest);

      if (amount == null) {
        return VoiceCommandResult(
          type: type,
          rawText: text,
          customer: matchedCustomers.length == 1 ? matchedCustomers.first : null,
          ambiguousCustomers: matchedCustomers.length > 1 ? matchedCustomers : null,
          error: matchedCustomers.isEmpty
              ? 'لم يتم التعرف على اسم العميل'
              : 'لم يتم التعرف على المبلغ المدفوع',
        );
      }

      if (matchedCustomers.isEmpty) {
        return VoiceCommandResult(
          type: type,
          rawText: text,
          paymentAmount: amount,
          error: 'لم يتم العثور على عميل بهذا الاسم',
        );
      }

      return VoiceCommandResult(
        type: type,
        rawText: text,
        customer: matchedCustomers.length == 1 ? matchedCustomers.first : null,
        ambiguousCustomers: matchedCustomers.length > 1 ? matchedCustomers : null,
        paymentAmount: amount,
        error: matchedCustomers.length > 1 ? 'يوجد أكثر من عميل بنفس الاسم، اختر العميل المطلوب' : null,
      );
    } else {
      // Sale: everything after the verb describes quantity + product
      final rest = words.sublist(verbIndex + 1);

      if (rest.isEmpty) {
        return VoiceCommandResult(
          type: type,
          rawText: text,
          customer: matchedCustomers.length == 1 ? matchedCustomers.first : null,
          ambiguousCustomers: matchedCustomers.length > 1 ? matchedCustomers : null,
          error: 'لم يتم التعرف على المنتج',
        );
      }

      final extraction = _extractProductAndQuantity(rest, products);

      if (matchedCustomers.isEmpty) {
        return VoiceCommandResult(
          type: type,
          rawText: text,
          product: extraction.product,
          quantity: extraction.quantity,
          error: 'لم يتم العثور على عميل بهذا الاسم',
        );
      }

      if (extraction.product == null) {
        return VoiceCommandResult(
          type: type,
          rawText: text,
          customer: matchedCustomers.length == 1 ? matchedCustomers.first : null,
          ambiguousCustomers: matchedCustomers.length > 1 ? matchedCustomers : null,
          quantity: extraction.quantity,
          error: 'لم يتم التعرف على المنتج، يمكنك اختياره يدويًا',
        );
      }

      return VoiceCommandResult(
        type: type,
        rawText: text,
        customer: matchedCustomers.length == 1 ? matchedCustomers.first : null,
        ambiguousCustomers: matchedCustomers.length > 1 ? matchedCustomers : null,
        product: extraction.product,
        quantity: extraction.quantity,
        error: matchedCustomers.length > 1 ? 'يوجد أكثر من عميل بنفس الاسم، اختر العميل المطلوب' : null,
      );
    }
  }

  /// Normalize Arabic text: remove diacritics, normalize alef/ya/ta-marbuta variants,
  /// remove extra punctuation, collapse whitespace.
  static String _normalize(String text) {
    var t = text.trim();
    // Remove tashkeel (diacritics)
    t = t.replaceAll(RegExp(r'[\u064B-\u065F\u0670]'), '');
    // Normalize alef variants
    t = t.replaceAll(RegExp(r'[إأآا]'), 'ا');
    // Normalize ta marbuta to ha (loosely) -- keep both forms searchable, but normalize input
    // We'll keep ة as is for product matching but also generate variants when matching
    // Normalize ى to ي
    t = t.replaceAll('ى', 'ي');
    // Remove common filler punctuation
    t = t.replaceAll(RegExp(r'[.,،؟!]'), ' ');
    // Collapse whitespace
    t = t.replaceAll(RegExp(r'\s+'), ' ');
    return t.trim().toLowerCase();
  }

  /// Match a spoken name against the customer list.
  /// Returns a list (possibly multiple matches if name is ambiguous, e.g. "أحمد").
  static List<Customer> _matchCustomer(String spokenName, List<Customer> customers) {
    final normalizedSpoken = _normalizeName(spokenName);

    // 1. Exact full-name match (normalized)
    final exact = customers.where((c) => _normalizeName(c.name) == normalizedSpoken).toList();
    if (exact.isNotEmpty) return exact;

    // 2. Spoken name matches the first word of customer's full name
    //    e.g. spoken "احمد" matches customer "احمد علي"
    final firstNameMatches = customers.where((c) {
      final customerWords = _normalizeName(c.name).split(' ');
      return customerWords.isNotEmpty && customerWords.first == normalizedSpoken;
    }).toList();
    if (firstNameMatches.isNotEmpty) return firstNameMatches;

    // 3. Customer name contains the spoken name as a substring
    final containsMatches = customers.where((c) {
      return _normalizeName(c.name).contains(normalizedSpoken);
    }).toList();
    if (containsMatches.isNotEmpty) return containsMatches;

    // 4. Spoken name contains customer's full name (e.g. spoken multiple words)
    final reverseContains = customers.where((c) {
      return normalizedSpoken.contains(_normalizeName(c.name));
    }).toList();
    if (reverseContains.isNotEmpty) return reverseContains;

    return [];
  }

  static String _normalizeName(String name) {
    var n = name.trim().toLowerCase();
    n = n.replaceAll(RegExp(r'[\u064B-\u065F\u0670]'), '');
    n = n.replaceAll(RegExp(r'[إأآا]'), 'ا');
    n = n.replaceAll('ى', 'ي');
    n = n.replaceAll(RegExp(r'\s+'), ' ');
    return n.trim();
  }

  /// Extract a numeric amount from words like "100 جنيه" or "مية جنيه" or "250"
  static double? _extractAmount(List<String> words) {
    for (final w in words) {
      // Skip currency words
      if (_currencyWords.contains(w)) continue;

      // Try direct numeric parse
      final num = double.tryParse(w);
      if (num != null) return num;

      // Try Arabic word numbers (including common amount words)
      final mapped = _amountWordValue(w);
      if (mapped != null) return mapped;
    }
    return null;
  }

  /// Maps common Arabic spoken amounts (مية = 100, الف = 1000, etc.) and digit words
  static double? _amountWordValue(String word) {
    const amountWords = {
      'مية': 100, 'مائة': 100, 'مئة': 100,
      'مايتين': 200, 'مئتين': 200, 'مائتين': 200,
      'تلتمية': 300, 'ثلاثمية': 300, 'ثلاثمائة': 300,
      'اربعمية': 400, 'أربعمية': 400,
      'خمسمية': 500, 'خمسمائة': 500,
      'الف': 1000, 'ألف': 1000,
    };
    if (amountWords.containsKey(word)) return amountWords[word]!.toDouble();
    if (_wordNumbers.containsKey(word)) return _wordNumbers[word]!;
    return null;
  }

  /// Result of product+quantity extraction
  static _ProductExtraction _extractProductAndQuantity(
    List<String> words,
    List<Product> products,
  ) {
    double quantity = 1;
    String remainingText = words.join(' ');

    // 1. Check for leading numeric quantity, e.g. "3 شيبسي"
    if (words.isNotEmpty) {
      final firstNum = double.tryParse(words.first);
      if (firstNum != null) {
        quantity = firstNum;
        remainingText = words.sublist(1).join(' ');
      } else if (_wordNumbers.containsKey(words.first)) {
        quantity = _wordNumbers[words.first]!;
        remainingText = words.sublist(1).join(' ');
      }
    }

    // 2. Check for dual suffix on the first remaining word, e.g. "علبتين" -> "علبة" x2
    final remainingWords = remainingText.split(' ').where((w) => w.isNotEmpty).toList();
    String dualStrippedText = remainingText;
    if (quantity == 1 && remainingWords.isNotEmpty) {
      final firstWord = remainingWords.first;
      if (firstWord.endsWith('تين') && firstWord.length > 3) {
        quantity = 2;
        final base = firstWord.substring(0, firstWord.length - 3) + 'ة';
        dualStrippedText = ([base] + remainingWords.sublist(1)).join(' ');
      } else if (firstWord.endsWith('ين') && firstWord.length > 2) {
        quantity = 2;
        final base = firstWord.substring(0, firstWord.length - 2);
        dualStrippedText = ([base] + remainingWords.sublist(1)).join(' ');
      }
    }

    // 3. Match product against name + aliases
    final product = _matchProduct(dualStrippedText, products) ??
        _matchProduct(remainingText, products);

    return _ProductExtraction(product: product, quantity: quantity);
  }

  /// Match free text against product names and aliases
  static Product? _matchProduct(String text, List<Product> products) {
    final normalized = _normalizeName(text);
    if (normalized.isEmpty) return null;

    // 1. Exact match on product name
    for (final p in products) {
      if (_normalizeName(p.name) == normalized) return p;
    }

    // 2. Exact match on alias
    for (final p in products) {
      for (final alias in p.aliases) {
        if (_normalizeName(alias) == normalized) return p;
      }
    }

    // 3. Substring match: product name/alias contained in spoken text, or vice versa
    for (final p in products) {
      final pName = _normalizeName(p.name);
      if (normalized.contains(pName) || pName.contains(normalized)) return p;
      for (final alias in p.aliases) {
        final aName = _normalizeName(alias);
        if (aName.isEmpty) continue;
        if (normalized.contains(aName) || aName.contains(normalized)) return p;
      }
    }

    // 4. Word-by-word match: any word of spoken text matches any word of product name/alias
    final spokenWords = normalized.split(' ');
    for (final p in products) {
      final pWords = _normalizeName(p.name).split(' ');
      for (final sw in spokenWords) {
        if (sw.length < 2) continue;
        if (pWords.contains(sw)) return p;
      }
      for (final alias in p.aliases) {
        final aWords = _normalizeName(alias).split(' ');
        for (final sw in spokenWords) {
          if (sw.length < 2) continue;
          if (aWords.contains(sw)) return p;
        }
      }
    }

    return null;
  }
}

class _ProductExtraction {
  final Product? product;
  final double quantity;
  _ProductExtraction({required this.product, required this.quantity});
}
