import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:permission_handler/permission_handler.dart';

class SpeechService {
  final stt.SpeechToText _speech = stt.SpeechToText();
  bool _isInitialized = false;

  Future<bool> initialize() async {
    if (_isInitialized) return true;

    final status = await Permission.microphone.request();
    if (!status.isGranted) return false;

    _isInitialized = await _speech.initialize(
      onError: (error) => print('Speech error: $error'),
      onStatus: (status) => print('Speech status: $status'),
    );
    return _isInitialized;
  }

  bool get isListening => _speech.isListening;
  bool get isAvailable => _speech.isAvailable;

  /// Start listening. [onResult] is called with recognized text (final result).
  /// [onPartialResult] is called continuously with partial text for live display.
  Future<void> startListening({
    required Function(String text) onResult,
    Function(String text)? onPartialResult,
    Function()? onDone,
  }) async {
    if (!_isInitialized) {
      final ok = await initialize();
      if (!ok) return;
    }

    await _speech.listen(
      onResult: (result) {
        if (result.finalResult) {
          onResult(result.recognizedWords);
          onDone?.call();
        } else {
          onPartialResult?.call(result.recognizedWords);
        }
      },
      localeId: 'ar-EG', // Egyptian Arabic for best results with colloquial commands
      listenOptions: stt.SpeechListenOptions(
        partialResults: true,
        cancelOnError: true,
        listenMode: stt.ListenMode.confirmation,
      ),
    );
  }

  Future<void> stopListening() async {
    await _speech.stop();
  }

  Future<void> cancel() async {
    await _speech.cancel();
  }
}
