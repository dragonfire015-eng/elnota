import 'dart:typed_data';
import 'dart:io';
import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:path_provider/path_provider.dart';
import 'package:intl/intl.dart';

import '../models/customer.dart';
import '../models/payment.dart';

/// Generates Arabic PDF statements (كشف حساب) for a customer.
class PdfReportService {
  /// Generate a PDF statement and return the saved file path.
  static Future<String> generateCustomerStatement({
    required Customer customer,
    required List<Transaction> transactions,
    required double totalPurchases,
    required double totalPayments,
    required String periodLabel,
    String shopName = 'محلي',
  }) async {
    final doc = pw.Document();

    final arabicFont = await _loadArabicFont();
    final arabicFontBold = await _loadArabicFontBold();

    final balance = totalPurchases - totalPayments;
    final dateFormat = DateFormat('yyyy/MM/dd');
    final currencyFormat = NumberFormat('#,##0.00');

    doc.addPage(
      pw.MultiPage(
        textDirection: pw.TextDirection.rtl,
        theme: pw.ThemeData.withFont(
          base: arabicFont,
          bold: arabicFontBold,
        ),
        pageFormat: PdfPageFormat.a4,
        header: (context) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.end,
          children: [
            pw.Text(
              shopName,
              style: pw.TextStyle(fontSize: 20, fontWeight: pw.FontWeight.bold),
              textDirection: pw.TextDirection.rtl,
            ),
            pw.SizedBox(height: 4),
            pw.Text(
              'كشف حساب عميل',
              style: pw.TextStyle(fontSize: 16),
              textDirection: pw.TextDirection.rtl,
            ),
            pw.Divider(),
          ],
        ),
        footer: (context) => pw.Container(
          alignment: pw.Alignment.center,
          margin: const pw.EdgeInsets.only(top: 10),
          child: pw.Text(
            'صفحة ${context.pageNumber} من ${context.pagesCount}',
            style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey),
          ),
        ),
        build: (context) => [
          pw.SizedBox(height: 8),
          pw.Container(
            padding: const pw.EdgeInsets.all(10),
            decoration: pw.BoxDecoration(
              color: PdfColors.grey100,
              borderRadius: pw.BorderRadius.circular(6),
            ),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.end,
              children: [
                pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    pw.Text('تاريخ التقرير: ${dateFormat.format(DateTime.now())}',
                        textDirection: pw.TextDirection.rtl, style: const pw.TextStyle(fontSize: 11)),
                    pw.Text('اسم العميل: ${customer.name}',
                        textDirection: pw.TextDirection.rtl,
                        style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold)),
                  ],
                ),
                if (customer.phone != null && customer.phone!.isNotEmpty)
                  pw.Padding(
                    padding: const pw.EdgeInsets.only(top: 4),
                    child: pw.Text('رقم الهاتف: ${customer.phone}',
                        textDirection: pw.TextDirection.rtl, style: const pw.TextStyle(fontSize: 11)),
                  ),
                pw.Padding(
                  padding: const pw.EdgeInsets.only(top: 4),
                  child: pw.Text('الفترة: $periodLabel',
                      textDirection: pw.TextDirection.rtl, style: const pw.TextStyle(fontSize: 11)),
                ),
              ],
            ),
          ),
          pw.SizedBox(height: 16),

          pw.Row(
            children: [
              _summaryBox('إجمالي المشتريات', currencyFormat.format(totalPurchases), PdfColors.red50, PdfColors.red900),
              pw.SizedBox(width: 8),
              _summaryBox('إجمالي المدفوعات', currencyFormat.format(totalPayments), PdfColors.green50, PdfColors.green900),
              pw.SizedBox(width: 8),
              _summaryBox('الرصيد المتبقي', currencyFormat.format(balance), PdfColors.blue50, PdfColors.blue900),
            ],
          ),
          pw.SizedBox(height: 16),

          pw.Text('تفاصيل العمليات',
              style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold),
              textDirection: pw.TextDirection.rtl),
          pw.SizedBox(height: 8),

          pw.Table(
            border: pw.TableBorder.all(color: PdfColors.grey400, width: 0.5),
            columnWidths: {
              0: const pw.FlexColumnWidth(2),
              1: const pw.FlexColumnWidth(3),
              2: const pw.FlexColumnWidth(2),
              3: const pw.FlexColumnWidth(2),
            },
            children: [
              pw.TableRow(
                decoration: const pw.BoxDecoration(color: PdfColors.grey300),
                children: [
                  _cell('التاريخ', isHeader: true),
                  _cell('البيان', isHeader: true),
                  _cell('المبلغ', isHeader: true),
                  _cell('النوع', isHeader: true),
                ],
              ),
              ...transactions.map((t) {
                final isPurchase = t.type == TransactionType.sale;
                return pw.TableRow(
                  children: [
                    _cell(dateFormat.format(t.date)),
                    _cell(t.extraInfo != null ? '${t.description} (${t.extraInfo})' : t.description),
                    _cell(currencyFormat.format(t.amount)),
                    _cell(isPurchase ? 'مشتريات' : 'دفعة',
                        color: isPurchase ? PdfColors.red : PdfColors.green),
                  ],
                );
              }),
            ],
          ),
          pw.SizedBox(height: 20),

          pw.Container(
            alignment: pw.Alignment.centerLeft,
            padding: const pw.EdgeInsets.all(12),
            decoration: pw.BoxDecoration(
              color: balance > 0 ? PdfColors.red50 : PdfColors.green50,
              borderRadius: pw.BorderRadius.circular(6),
              border: pw.Border.all(
                color: balance > 0 ? PdfColors.red : PdfColors.green,
                width: 1,
              ),
            ),
            child: pw.Text(
              'الرصيد النهائي المستحق: ${currencyFormat.format(balance)} جنيه',
              style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold),
              textDirection: pw.TextDirection.rtl,
            ),
          ),
        ],
      ),
    );

    final bytes = await doc.save();
    return _saveToFile(bytes, customer.name);
  }

  static pw.Widget _summaryBox(String title, String value, PdfColor bgColor, PdfColor textColor) {
    return pw.Expanded(
      child: pw.Container(
        padding: const pw.EdgeInsets.all(10),
        decoration: pw.BoxDecoration(
          color: bgColor,
          borderRadius: pw.BorderRadius.circular(6),
        ),
        child: pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.center,
          children: [
            pw.Text(title,
                style: pw.TextStyle(fontSize: 10, color: textColor),
                textDirection: pw.TextDirection.rtl,
                textAlign: pw.TextAlign.center),
            pw.SizedBox(height: 4),
            pw.Text(value,
                style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold, color: textColor),
                textDirection: pw.TextDirection.rtl),
          ],
        ),
      ),
    );
  }

  static pw.Widget _cell(String text, {bool isHeader = false, PdfColor? color}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.all(6),
      child: pw.Text(
        text,
        textDirection: pw.TextDirection.rtl,
        textAlign: pw.TextAlign.center,
        style: pw.TextStyle(
          fontSize: isHeader ? 11 : 10,
          fontWeight: isHeader ? pw.FontWeight.bold : pw.FontWeight.normal,
          color: color,
        ),
      ),
    );
  }

  static Future<pw.Font> _loadArabicFont() async {
    try {
      final data = await rootBundle.load('assets/fonts/NotoSansArabic-Regular.ttf');
      return pw.Font.ttf(data);
    } catch (_) {
      // Fallback if font asset is missing - Arabic text may not render correctly
      // until a proper Arabic TTF font is added to assets/fonts/.
      return pw.Font.helvetica();
    }
  }

  static Future<pw.Font> _loadArabicFontBold() async {
    try {
      final data = await rootBundle.load('assets/fonts/NotoSansArabic-Bold.ttf');
      return pw.Font.ttf(data);
    } catch (_) {
      return pw.Font.helveticaBold();
    }
  }

  static Future<String> _saveToFile(Uint8List bytes, String customerName) async {
    final dir = await getApplicationDocumentsDirectory();
    final reportsDir = Directory('${dir.path}/reports');
    if (!await reportsDir.exists()) {
      await reportsDir.create(recursive: true);
    }
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final safeName = customerName.replaceAll(RegExp(r'[^\w\u0600-\u06FF]'), '_');
    final file = File('${reportsDir.path}/statement_${safeName}_$timestamp.pdf');
    await file.writeAsBytes(bytes);
    return file.path;
  }
}
