import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_theme.dart';
import '../../models/product.dart';
import '../../providers/data_providers.dart';
import '../../providers/repository_providers.dart';
import 'product_form_screen.dart';

class ProductListScreen extends ConsumerWidget {
  final bool embedded;
  const ProductListScreen({super.key, this.embedded = false});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final productsAsync = ref.watch(allProductsProvider);

    final content = productsAsync.when(
      data: (products) {
        if (products.isEmpty) {
          return const Center(child: Text('لا توجد منتجات. اضغط + للإضافة.'));
        }
        return ListView.builder(
          padding: const EdgeInsets.fromLTRB(8, 12, 8, 100),
          itemCount: products.length,
          itemBuilder: (context, index) {
            final p = products[index];
            return Dismissible(
              key: Key('product_${p.id}'),
              direction: DismissDirection.endToStart,
              background: Container(
                color: AppTheme.errorColor,
                alignment: Alignment.centerLeft,
                padding: const EdgeInsets.only(left: 20),
                child: const Icon(Icons.delete, color: Colors.white),
              ),
              confirmDismiss: (_) => _confirmDelete(context, p),
              onDismissed: (_) => _delete(ref, p),
              child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.inventory_2_outlined)),
                title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: p.aliases.isNotEmpty ? Text('مسميات أخرى: ${p.aliases.join(", ")}') : null,
                trailing: Text('${p.price.toStringAsFixed(0)} ج', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductFormScreen(product: p))),
              ),
            );
          },
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, st) => Center(child: Text('خطأ: $e')),
    );

    if (embedded) {
      return Stack(
        children: [
          Column(
            children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 12, 16, 0),
                child: Align(
                  alignment: Alignment.centerRight,
                  child: Text('المنتجات', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                ),
              ),
              Expanded(child: content),
            ],
          ),
          Positioned(
            bottom: 16,
            left: 16,
            child: FloatingActionButton(
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProductFormScreen())),
              child: const Icon(Icons.add),
            ),
          ),
        ],
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('المنتجات')),
      body: content,
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProductFormScreen())),
        child: const Icon(Icons.add),
      ),
    );
  }

  Future<bool> _confirmDelete(BuildContext context, Product product) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف المنتج'),
        content: Text('هل تريد حذف "${product.name}"؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('حذف', style: TextStyle(color: AppTheme.errorColor))),
        ],
      ),
    );
    return result ?? false;
  }

  Future<void> _delete(WidgetRef ref, Product product) async {
    await ref.read(productRepositoryProvider).deleteProduct(product.id!);
    ref.read(dataRefreshProvider.notifier).state++;
  }
}
