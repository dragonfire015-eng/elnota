import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/product.dart';
import '../../providers/data_providers.dart';
import '../../providers/repository_providers.dart';

class ProductFormScreen extends ConsumerStatefulWidget {
  final Product? product;

  const ProductFormScreen({super.key, this.product});

  @override
  ConsumerState<ProductFormScreen> createState() => _ProductFormScreenState();
}

class _ProductFormScreenState extends ConsumerState<ProductFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _priceController;
  late TextEditingController _aliasesController;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.product?.name ?? '');
    _priceController = TextEditingController(
      text: widget.product != null ? widget.product!.price.toStringAsFixed(0) : '',
    );
    _aliasesController = TextEditingController(text: widget.product?.aliases.join(', ') ?? '');
  }

  @override
  void dispose() {
    _nameController.dispose();
    _priceController.dispose();
    _aliasesController.dispose();
    super.dispose();
  }

  bool get _isEdit => widget.product != null;

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);

    final repo = ref.read(productRepositoryProvider);
    final price = double.tryParse(_priceController.text) ?? 0;
    final aliases = _aliasesController.text
        .split(',')
        .map((a) => a.trim())
        .where((a) => a.isNotEmpty)
        .toList();

    try {
      if (_isEdit) {
        await repo.updateProduct(widget.product!.copyWith(
          name: _nameController.text.trim(),
          price: price,
          aliases: aliases,
        ));
      } else {
        await repo.insertProduct(Product(
          name: _nameController.text.trim(),
          price: price,
          aliases: aliases,
        ));
      }

      ref.read(dataRefreshProvider.notifier).state++;

      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(_isEdit ? 'تم تعديل المنتج' : 'تم إضافة المنتج')),
        );
      }
    } catch (e) {
      setState(() => _saving = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('خطأ: $e')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? 'تعديل المنتج' : 'إضافة منتج')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(labelText: 'اسم المنتج *', prefixIcon: Icon(Icons.inventory_2)),
                validator: (val) => (val == null || val.trim().isEmpty) ? 'الاسم مطلوب' : null,
                textInputAction: TextInputAction.next,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _priceController,
                decoration: const InputDecoration(labelText: 'السعر الافتراضي *', prefixIcon: Icon(Icons.attach_money), suffixText: 'جنيه'),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                validator: (val) {
                  if (val == null || val.trim().isEmpty) return 'السعر مطلوب';
                  final price = double.tryParse(val);
                  if (price == null || price <= 0) return 'السعر غير صحيح';
                  return null;
                },
                textInputAction: TextInputAction.next,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _aliasesController,
                decoration: const InputDecoration(
                  labelText: 'مسميات أخرى (اختياري)',
                  hintText: 'مثال: كولا، بيبسي، غازي',
                  prefixIcon: Icon(Icons.label_outline),
                  helperText: 'كلمات يستخدمها العملاء للتعرف عليها صوتيًا، مفصولة بفاصلة',
                  helperMaxLines: 2,
                ),
                maxLines: 2,
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: _saving ? null : _save,
                child: _saving
                    ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : Text(_isEdit ? 'حفظ التعديلات' : 'إضافة المنتج'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
