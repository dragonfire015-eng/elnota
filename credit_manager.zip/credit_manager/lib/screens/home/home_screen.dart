import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_theme.dart';
import '../../providers/data_providers.dart';
import '../../widgets/common_widgets.dart';
import '../../widgets/voice_command_widget.dart';
import '../customer/customer_list_screen.dart';
import '../customer/customer_detail_screen.dart';
import '../product/product_list_screen.dart';
import '../settings/settings_screen.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  int _currentIndex = 0;

  final List<Widget> _pages = const [
    _DashboardTab(),
    CustomerListScreen(embedded: true),
    ProductListScreen(embedded: true),
    SettingsScreen(embedded: true),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: _pages[_currentIndex]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: (index) => setState(() => _currentIndex = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'العملاء'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), selectedIcon: Icon(Icons.inventory_2), label: 'المنتجات'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'الإعدادات'),
        ],
      ),
      floatingActionButton: _currentIndex == 0
          ? FloatingActionButton.large(
              onPressed: () => showVoiceCommandDialog(context, ref),
              backgroundColor: AppTheme.primaryColor,
              child: const Icon(Icons.mic, size: 36, color: Colors.white),
            )
          : null,
    );
  }
}

class _DashboardTab extends ConsumerWidget {
  const _DashboardTab();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final statsAsync = ref.watch(dashboardStatsProvider);

    return RefreshIndicator(
      onRefresh: () async {
        ref.read(dataRefreshProvider.notifier).state++;
        await Future.delayed(const Duration(milliseconds: 300));
      },
      child: statsAsync.when(
        data: (stats) => ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 100),
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('إدارة الديون', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                IconButton(
                  icon: const Icon(Icons.search),
                  onPressed: () => _showQuickSearch(context, ref),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // Quick command hint
            Card(
              color: AppTheme.primaryColor.withOpacity(0.08),
              child: const Padding(
                padding: EdgeInsets.all(14),
                child: Row(
                  children: [
                    Icon(Icons.mic, color: AppTheme.primaryColor),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'اضغط على زر الميكروفون وقل مثلاً: "أحمد أخذ علبة سجائر" أو "محمد دفع 100 جنيه"',
                        style: TextStyle(fontSize: 13),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 1.7,
              children: [
                StatCard(
                  title: 'إجمالي المديونيات',
                  value: '${stats.totalDebts.toStringAsFixed(0)} ج',
                  icon: Icons.account_balance_wallet,
                  color: AppTheme.errorColor,
                ),
                StatCard(
                  title: 'عدد العملاء',
                  value: '${stats.customerCount}',
                  icon: Icons.people,
                  color: AppTheme.secondaryColor,
                ),
                StatCard(
                  title: 'مبيعات الشهر',
                  value: '${stats.monthSales.toStringAsFixed(0)} ج',
                  icon: Icons.trending_up,
                  color: AppTheme.warningColor,
                ),
                StatCard(
                  title: 'تحصيلات الشهر',
                  value: '${stats.monthPayments.toStringAsFixed(0)} ج',
                  icon: Icons.savings,
                  color: AppTheme.successColor,
                ),
              ],
            ),
            const SizedBox(height: 20),

            if (stats.latePayers.isNotEmpty) ...[
              Card(
                color: AppTheme.warningColor.withOpacity(0.1),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.notifications_active, color: AppTheme.warningColor),
                          const SizedBox(width: 8),
                          const Text('عملاء متأخرون في السداد', style: TextStyle(fontWeight: FontWeight.bold)),
                        ],
                      ),
                      const SizedBox(height: 8),
                      ...stats.latePayers.map((c) => ListTile(
                            dense: true,
                            contentPadding: EdgeInsets.zero,
                            title: Text(c.customer.name),
                            trailing: Text('${c.balance.toStringAsFixed(0)} ج', style: const TextStyle(fontWeight: FontWeight.bold)),
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(builder: (_) => CustomerDetailScreen(customerId: c.customer.id!)),
                            ),
                          )),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],

            if (stats.topDebtors.isNotEmpty) ...[
              const Text('أكثر العملاء مديونية', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Card(
                child: Column(
                  children: stats.topDebtors.map((c) {
                    return ListTile(
                      leading: CircleAvatar(child: Text(c.customer.name.substring(0, 1))),
                      title: Text(c.customer.name),
                      trailing: Text(
                        '${c.balance.toStringAsFixed(0)} ج',
                        style: const TextStyle(fontWeight: FontWeight.bold, color: AppTheme.errorColor),
                      ),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => CustomerDetailScreen(customerId: c.customer.id!)),
                      ),
                    );
                  }).toList(),
                ),
              ),
              const SizedBox(height: 20),
            ],

            const Text('آخر العمليات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            if (stats.recentTransactions.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 20),
                child: Center(child: Text('لا توجد عمليات بعد')),
              )
            else
              Card(
                child: Column(
                  children: stats.recentTransactions.map((t) {
                    return FutureBuilder(
                      future: ref.read(customerRepositoryProvider).getCustomerById(t.customerId),
                      builder: (context, snapshot) {
                        final name = snapshot.data?.name;
                        return TransactionTile(
                          transaction: t,
                          customerName: name,
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => CustomerDetailScreen(customerId: t.customerId)),
                          ),
                        );
                      },
                    );
                  }).toList(),
                ),
              ),
          ],
        ),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, st) => Center(child: Text('خطأ: $e')),
      ),
    );
  }

  void _showQuickSearch(BuildContext context, WidgetRef ref) {
    showSearch(
      context: context,
      delegate: _CustomerSearchDelegate(ref),
    );
  }
}

class _CustomerSearchDelegate extends SearchDelegate {
  final WidgetRef ref;
  _CustomerSearchDelegate(this.ref);

  @override
  List<Widget> buildActions(BuildContext context) => [
        if (query.isNotEmpty)
          IconButton(icon: const Icon(Icons.clear), onPressed: () => query = ''),
      ];

  @override
  Widget buildLeading(BuildContext context) => IconButton(
        icon: const Icon(Icons.arrow_back),
        onPressed: () => close(context, null),
      );

  @override
  Widget buildResults(BuildContext context) => _buildSuggestions(context);

  @override
  Widget buildSuggestions(BuildContext context) => _buildSuggestions(context);

  Widget _buildSuggestions(BuildContext context) {
    return FutureBuilder(
      future: ref.read(customerRepositoryProvider).searchCustomers(query),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        final customers = snapshot.data!;
        if (customers.isEmpty) return const Center(child: Text('لا توجد نتائج'));
        return ListView.builder(
          itemCount: customers.length,
          itemBuilder: (context, index) {
            final c = customers[index];
            return ListTile(
              leading: CircleAvatar(child: Text(c.name.substring(0, 1))),
              title: Text(c.name),
              subtitle: c.phone != null ? Text(c.phone!) : null,
              onTap: () {
                close(context, null);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => CustomerDetailScreen(customerId: c.id!)),
                );
              },
            );
          },
        );
      },
    );
  }
}
