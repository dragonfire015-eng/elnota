import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:open_filex/open_filex.dart';

import '../../core/theme/app_theme.dart';
import '../../models/payment.dart';
import '../../providers/data_providers.dart';
import '../../providers/repository_providers.dart';
import '../../services/pdf_report_service.dart';
import '../../services/backup_service.dart';
import '../../widgets/common_widgets.dart';

enum StatementFilter { today, week, month, custom, all }

class StatementScreen extends ConsumerStatefulWidget {
  final int customerId;
  const StatementScreen({super.key, required this.customerId});

  @override
  ConsumerState<StatementScreen> createState() => _StatementScreenState();
}

class _StatementScreenState extends ConsumerState<StatementScreen> {
  StatementFilter _filter = StatementFilter.all;
  DateTimeRange? _customRange;
  bool _generating = false;

  @override
  Widget build(BuildContext context) {
    final balanceAsync = ref.watch(customerBalanceProvider(widget.customerId));
    final transactionsAsync = ref.watch(customerTransactionsProvider(widget.customerId));

    return Scaffold(
      appBar: AppBar(
        title: const Text('كشف الحساب'),
        actions: [
          IconButton(
            icon: _generating
                ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.picture_as_pdf),
            onPressed: _generating ? null : () => _generatePdf(context),
          ),
        ],
      ),
      body: balanceAsync.when(
        data: (balance) {
          return transactionsAsync.when(
            data: (allTransactions) {
              final filtered = _applyFilter(allTransactions);
              final totals = _calculateTotals(filtered);

              return Column(
                children: [
                  // Filter chips
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          _filterChip('الكل', StatementFilter.all),
                          const SizedBox(width: 8),
                          _filterChip('اليوم', StatementFilter.today),
                          const SizedBox(width: 8),
                          _filterChip('الأسبوع', StatementFilter.week),
                          const SizedBox(width: 8),
                          _filterChip('الشهر', StatementFilter.month),
                          const SizedBox(width: 8),
                          _filterChip('فترة مخصصة', StatementFilter.custom),
                        ],
                      ),
                    ),
                  ),

                  // Summary
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      children: [
                        Expanded(
                          child: StatCard(
                            title: 'المشتريات',
                            value: '${totals.purchases.toStringAsFixed(0)} ج',
                            icon: Icons.shopping_cart,
                            color: AppTheme.errorColor,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: StatCard(
                            title: 'المدفوعات',
                            value: '${totals.payments.toStringAsFixed(0)} ج',
                            icon: Icons.payments,
                            color: AppTheme.successColor,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: StatCard(
                      title: 'الرصيد الحالي الإجمالي',
                      value: '${balance.balance.toStringAsFixed(2)} ج',
                      icon: Icons.account_balance_wallet,
                      color: balance.balance > 0 ? AppTheme.errorColor : AppTheme.successColor,
                    ),
                  ),
                  const SizedBox(height: 8),

                  Expanded(
                    child: filtered.isEmpty
                        ? const Center(child: Text('لا توجد عمليات في هذه الفترة'))
                        : ListView.builder(
                            padding: const EdgeInsets.only(bottom: 20),
                            itemCount: filtered.length,
                            itemBuilder: (context, index) {
                              final t = filtered[index];
                              return TransactionTile(
                                transaction: t,
                                onDelete: t.isDeleted ? null : () => _deleteTransaction(t),
                                onRestore: t.isDeleted ? () => _restoreTransaction(t) : null,
                              );
                            },
                          ),
                  ),
                ],
              );
            },
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (e, st) => Center(child: Text('خطأ: $e')),
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, st) => Center(child: Text('خطأ: $e')),
      ),
    );
  }

  Widget _filterChip(String label, StatementFilter filter) {
    return ChoiceChip(
      label: Text(label),
      selected: _filter == filter,
      onSelected: (selected) async {
        if (filter == StatementFilter.custom) {
          final range = await showDateRangePicker(
            context: context,
            firstDate: DateTime(2020),
            lastDate: DateTime.now(),
            locale: const Locale('ar'),
          );
          if (range != null) {
            setState(() {
              _customRange = range;
              _filter = filter;
            });
          }
        } else {
          setState(() => _filter = filter);
        }
      },
    );
  }

  List<Transaction> _applyFilter(List<Transaction> transactions) {
    final now = DateTime.now();
    DateTime? start;
    DateTime? end;

    switch (_filter) {
      case StatementFilter.today:
        start = DateTime(now.year, now.month, now.day);
        end = start.add(const Duration(days: 1));
        break;
      case StatementFilter.week:
        start = now.subtract(Duration(days: now.weekday % 7));
        start = DateTime(start.year, start.month, start.day);
        end = start.add(const Duration(days: 7));
        break;
      case StatementFilter.month:
        start = DateTime(now.year, now.month, 1);
        end = DateTime(now.year, now.month + 1, 1);
        break;
      case StatementFilter.custom:
        if (_customRange != null) {
          start = _customRange!.start;
          end = _customRange!.end.add(const Duration(days: 1));
        }
        break;
      case StatementFilter.all:
        break;
    }

    if (start == null || end == null) return transactions.where((t) => !t.isDeleted).toList();

    return transactions.where((t) {
      return !t.isDeleted && t.date.isAfter(start!) && t.date.isBefore(end!);
    }).toList();
  }

  _Totals _calculateTotals(List<Transaction> transactions) {
    double purchases = 0;
    double payments = 0;
    for (final t in transactions) {
      if (t.type == TransactionType.sale) {
        purchases += t.amount;
      } else {
        payments += t.amount;
      }
    }
    return _Totals(purchases: purchases, payments: payments);
  }

  String _periodLabel() {
    switch (_filter) {
      case StatementFilter.today:
        return 'اليوم';
      case StatementFilter.week:
        return 'هذا الأسبوع';
      case StatementFilter.month:
        return 'هذا الشهر';
      case StatementFilter.custom:
        if (_customRange != null) {
          final fmt = DateFormat('yyyy/MM/dd');
          return '${fmt.format(_customRange!.start)} - ${fmt.format(_customRange!.end)}';
        }
        return 'فترة مخصصة';
      case StatementFilter.all:
        return 'كل العمليات';
    }
  }

  Future<void> _generatePdf(BuildContext context) async {
    setState(() => _generating = true);

    try {
      final customerRepo = ref.read(customerRepositoryProvider);
      final customer = await customerRepo.getCustomerById(widget.customerId);
      if (customer == null) throw Exception('العميل غير موجود');

      final allTransactions = await ref.read(customerTransactionsProvider(widget.customerId).future);
      final filtered = _applyFilter(allTransactions);
      final totals = _calculateTotals(filtered);

      final settingsRepo = ref.read(settingsRepositoryProvider);
      final shopName = await settingsRepo.getShopName();

      // Sort ascending for the PDF (chronological)
      final sorted = List<Transaction>.from(filtered)..sort((a, b) => a.date.compareTo(b.date));

      final path = await PdfReportService.generateCustomerStatement(
        customer: customer,
        transactions: sorted,
        totalPurchases: totals.purchases,
        totalPayments: totals.payments,
        periodLabel: _periodLabel(),
        shopName: shopName,
      );

      if (!context.mounted) return;

      await showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('تم إنشاء التقرير'),
          content: const Text('تم إنشاء ملف PDF بنجاح. ما هو الإجراء المطلوب؟'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('إغلاق')),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                OpenFilex.open(path);
              },
              child: const Text('فتح'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                BackupService.shareFile(path, text: 'كشف حساب - ${customer.name}');
              },
              child: const Text('مشاركة'),
            ),
          ],
        ),
      );
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('خطأ: $e')));
      }
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  Future<void> _deleteTransaction(Transaction t) async {
    if (t.type == TransactionType.sale) {
      await ref.read(saleRepositoryProvider).softDeleteSale(t.id);
    } else {
      await ref.read(paymentRepositoryProvider).softDeletePayment(t.id);
    }
    ref.read(dataRefreshProvider.notifier).state++;
  }

  Future<void> _restoreTransaction(Transaction t) async {
    if (t.type == TransactionType.sale) {
      await ref.read(saleRepositoryProvider).restoreSale(t.id);
    } else {
      await ref.read(paymentRepositoryProvider).restorePayment(t.id);
    }
    ref.read(dataRefreshProvider.notifier).state++;
  }
}

class _Totals {
  final double purchases;
  final double payments;
  _Totals({required this.purchases, required this.payments});
}
