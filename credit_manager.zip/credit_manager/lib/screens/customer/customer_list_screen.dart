import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_theme.dart';
import '../../models/customer.dart';
import '../../providers/data_providers.dart';
import '../../providers/repository_providers.dart';
import 'customer_detail_screen.dart';
import 'customer_form_screen.dart';

class CustomerListScreen extends ConsumerStatefulWidget {
  final bool embedded;
  const CustomerListScreen({super.key, this.embedded = false});

  @override
  ConsumerState<CustomerListScreen> createState() => _CustomerListScreenState();
}

class _CustomerListScreenState extends ConsumerState<CustomerListScreen> {
  final TextEditingController _searchController = TextEditingController();

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final query = ref.watch(customerSearchQueryProvider);
    final customersAsync = ref.watch(customersWithBalancesProvider);

    final content = Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Row(
            children: [
              if (!widget.embedded)
                IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => Navigator.pop(context)),
              Expanded(
                child: TextField(
                  controller: _searchController,
                  decoration: InputDecoration(
                    hintText: 'بحث عن عميل...',
                    prefixIcon: const Icon(Icons.search),
                    suffixIcon: query.isNotEmpty
                        ? IconButton(
                            icon: const Icon(Icons.clear),
                            onPressed: () {
                              _searchController.clear();
                              ref.read(customerSearchQueryProvider.notifier).state = '';
                            },
                          )
                        : null,
                  ),
                  onChanged: (val) => ref.read(customerSearchQueryProvider.notifier).state = val,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: customersAsync.when(
            data: (customers) {
              final filtered = query.isEmpty
                  ? customers
                  : customers.where((c) => _matchesQuery(c.customer.name, query)).toList();

              if (filtered.isEmpty) {
                return const Center(child: Text('لا يوجد عملاء'));
              }

              return ListView.builder(
                padding: const EdgeInsets.only(bottom: 100),
                itemCount: filtered.length,
                itemBuilder: (context, index) {
                  final c = filtered[index];
                  return Dismissible(
                    key: Key('customer_${c.customer.id}'),
                    direction: DismissDirection.endToStart,
                    background: Container(
                      color: AppTheme.errorColor,
                      alignment: Alignment.centerLeft,
                      padding: const EdgeInsets.only(left: 20),
                      child: const Icon(Icons.delete, color: Colors.white),
                    ),
                    confirmDismiss: (_) => _confirmDelete(context, c.customer),
                    onDismissed: (_) => _deleteCustomer(c.customer),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: c.balance > 0
                            ? AppTheme.errorColor.withOpacity(0.15)
                            : AppTheme.successColor.withOpacity(0.15),
                        child: Text(
                          c.customer.name.substring(0, 1),
                          style: TextStyle(
                            color: c.balance > 0 ? AppTheme.errorColor : AppTheme.successColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      title: Text(c.customer.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: c.customer.phone != null ? Text(c.customer.phone!) : null,
                      trailing: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            '${c.balance.toStringAsFixed(0)} ج',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              color: c.balance > 0 ? AppTheme.errorColor : AppTheme.successColor,
                            ),
                          ),
                          Text(c.balance > 0 ? 'مديون' : 'لا يوجد دين', style: const TextStyle(fontSize: 11)),
                        ],
                      ),
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => CustomerDetailScreen(customerId: c.customer.id!)),
                      ),
                    ),
                  );
                },
              );
            },
            loading: () => const Center(child: CircularProgressIndicator()),
            error: (e, st) => Center(child: Text('خطأ: $e')),
          ),
        ),
      ],
    );

    if (widget.embedded) {
      return Stack(
        children: [
          content,
          Positioned(
            bottom: 16,
            left: 16,
            child: FloatingActionButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const CustomerFormScreen()),
              ),
              child: const Icon(Icons.add),
            ),
          ),
        ],
      );
    }

    return Scaffold(
      body: SafeArea(child: content),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const CustomerFormScreen()),
        ),
        child: const Icon(Icons.add),
      ),
    );
  }

  bool _matchesQuery(String name, String query) {
    return name.toLowerCase().contains(query.toLowerCase());
  }

  Future<bool> _confirmDelete(BuildContext context, Customer customer) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف العميل'),
        content: Text('هل تريد حذف "${customer.name}"؟ سيتم حذف جميع العمليات المرتبطة به.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف', style: TextStyle(color: AppTheme.errorColor)),
          ),
        ],
      ),
    );
    return result ?? false;
  }

  Future<void> _deleteCustomer(Customer customer) async {
    final repo = ref.read(customerRepositoryProvider);
    await repo.deleteCustomer(customer.id!);
    ref.read(dataRefreshProvider.notifier).state++;
  }
}
