import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/theme/app_theme.dart';
import '../../models/payment.dart';
import '../../models/sale.dart';
import '../../providers/data_providers.dart';
import '../../providers/repository_providers.dart';
import '../../widgets/common_widgets.dart';
import 'customer_form_screen.dart';
import '../statement/statement_screen.dart';

class CustomerDetailScreen extends ConsumerWidget {
  final int customerId;

  const CustomerDetailScreen({super.key, required this.customerId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final balanceAsync = ref.watch(customerBalanceProvider(customerId));
    final transactionsAsync = ref.watch(customerTransactionsProvider(customerId));
    final productsAsync = ref.watch(allProductsProvider);

    return Scaffold(
      appBar: AppBar(
        title: balanceAsync.maybeWhen(
          data: (b) => Text(b.customer.name),
          orElse: () => const Text('تفاصيل العميل'),
        ),
        actions: [
          balanceAsync.maybeWhen(
            data: (b) => PopupMenuButton<String>(
              onSelected: (val) {
                if (val == 'edit') {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => CustomerFormScreen(customer: b.customer)));
                } else if (val == 'statement') {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => StatementScreen(customerId: customerId)));
                }
              },
              itemBuilder: (context) => [
                const PopupMenuItem(value: 'edit', child: Text('تعديل بيانات العميل')),
                const PopupMenuItem(value: 'statement', child: Text('كشف الحساب الكامل')),
              ],
            ),
            orElse: () => const SizedBox.shrink(),
          ),
        ],
      ),
      body: balanceAsync.when(
        data: (balance) => ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Debt limit alert
            if (balance.customer.debtLimit > 0 && balance.balance >= balance.customer.debtLimit)
              Card(
                color: AppTheme.warningColor.withOpacity(0.12),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    children: [
                      const Icon(Icons.warning_amber, color: AppTheme.warningColor),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'تنبيه: تجاوز دين العميل الحد المحدد (${balance.customer.debtLimit.toStringAsFixed(0)} ج)',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            if (balance.customer.debtLimit > 0 && balance.balance >= balance.customer.debtLimit)
              const SizedBox(height: 12),

            // Balance card
            Card(
              color: balance.balance > 0
                  ? AppTheme.errorColor.withOpacity(0.08)
                  : AppTheme.successColor.withOpacity(0.08),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Text(
                      balance.balance > 0 ? 'الرصيد المستحق' : 'لا يوجد دين',
                      style: const TextStyle(fontSize: 14),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${balance.balance.toStringAsFixed(2)} جنيه',
                      style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.bold,
                        color: balance.balance > 0 ? AppTheme.errorColor : AppTheme.successColor,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Column(children: [
                          const Text('إجمالي المشتريات', style: TextStyle(fontSize: 12)),
                          Text('${balance.totalPurchases.toStringAsFixed(0)} ج',
                              style: const TextStyle(fontWeight: FontWeight.bold)),
                        ]),
                        Column(children: [
                          const Text('إجمالي المدفوعات', style: TextStyle(fontSize: 12)),
                          Text('${balance.totalPayments.toStringAsFixed(0)} ج',
                              style: const TextStyle(fontWeight: FontWeight.bold)),
                        ]),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Record payment button
            ElevatedButton.icon(
              icon: const Icon(Icons.payments),
              label: const Text('تسجيل دفعة'),
              style: ElevatedButton.styleFrom(backgroundColor: AppTheme.successColor),
              onPressed: () => _showPaymentDialog(context, ref, balance.customer.id!),
            ),
            const SizedBox(height: 16),

            // Quick-add products
            const Text('إضافة منتج بضغطة واحدة', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            productsAsync.when(
              data: (products) {
                if (products.isEmpty) return const Text('لا توجد منتجات. أضف منتجات من الصفحة الرئيسية.');
                return Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: products.map((p) {
                    return ActionChip(
                      avatar: const Icon(Icons.add_shopping_cart, size: 18),
                      label: Text('${p.name} (${p.price.toStringAsFixed(0)} ج)'),
                      onPressed: () => _quickAddProduct(context, ref, balance.customer.id!, p),
                    );
                  }).toList(),
                );
              },
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, st) => Text('خطأ: $e'),
            ),
            const SizedBox(height: 20),

            // Recent transactions
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('آخر العمليات', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                TextButton(
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => StatementScreen(customerId: customerId)),
                  ),
                  child: const Text('عرض الكل'),
                ),
              ],
            ),
            transactionsAsync.when(
              data: (transactions) {
                if (transactions.isEmpty) return const Padding(padding: EdgeInsets.all(16), child: Text('لا توجد عمليات'));
                final recent = transactions.take(10).toList();
                return Card(
                  child: Column(
                    children: recent.map((t) {
                      return TransactionTile(
                        transaction: t,
                        onDelete: t.isDeleted ? null : () => _deleteTransaction(ref, t),
                        onRestore: t.isDeleted ? () => _restoreTransaction(ref, t) : null,
                      );
                    }).toList(),
                  ),
                );
              },
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, st) => Text('خطأ: $e'),
            ),
          ],
        ),
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, st) => Center(child: Text('خطأ: $e')),
      ),
    );
  }

  Future<void> _quickAddProduct(BuildContext context, WidgetRef ref, int customerId, dynamic product) async {
    final saleRepo = ref.read(saleRepositoryProvider);
    await saleRepo.insertSale(Sale(
      customerId: customerId,
      productId: product.id,
      productName: product.name,
      quantity: 1,
      unitPrice: product.price,
      total: product.price,
    ));
    ref.read(dataRefreshProvider.notifier).state++;

    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تم تسجيل: ${product.name}'), duration: const Duration(seconds: 1)),
      );
    }
  }

  Future<void> _showPaymentDialog(BuildContext context, WidgetRef ref, int customerId) async {
    final controller = TextEditingController();

    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تسجيل دفعة'),
        content: TextField(
          controller: controller,
          autofocus: true,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(labelText: 'المبلغ', suffixText: 'جنيه'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          ElevatedButton(
            onPressed: () async {
              final amount = double.tryParse(controller.text);
              if (amount == null || amount <= 0) {
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('مبلغ غير صحيح')));
                return;
              }
              final paymentRepo = ref.read(paymentRepositoryProvider);
              await paymentRepo.insertPayment(Payment(customerId: customerId, amount: amount));
              ref.read(dataRefreshProvider.notifier).state++;
              if (context.mounted) Navigator.pop(context);
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteTransaction(WidgetRef ref, Transaction t) async {
    if (t.type == TransactionType.sale) {
      await ref.read(saleRepositoryProvider).softDeleteSale(t.id);
    } else {
      await ref.read(paymentRepositoryProvider).softDeletePayment(t.id);
    }
    ref.read(dataRefreshProvider.notifier).state++;
  }

  Future<void> _restoreTransaction(WidgetRef ref, Transaction t) async {
    if (t.type == TransactionType.sale) {
      await ref.read(saleRepositoryProvider).restoreSale(t.id);
    } else {
      await ref.read(paymentRepositoryProvider).restorePayment(t.id);
    }
    ref.read(dataRefreshProvider.notifier).state++;
  }
}
