import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../providers/data_providers.dart';
import '../../providers/repository_providers.dart';
import '../../services/backup_service.dart';

class SettingsScreen extends ConsumerStatefulWidget {
  final bool embedded;
  const SettingsScreen({super.key, this.embedded = false});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  double _debtThreshold = 500;
  int _latePaymentDays = 30;
  String _shopName = 'محلي';
  bool _loaded = false;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final repo = ref.read(settingsRepositoryProvider);
    _debtThreshold = await repo.getDebtAlertThreshold();
    _latePaymentDays = await repo.getLatePaymentDays();
    _shopName = await repo.getShopName();
    setState(() => _loaded = true);
  }

  @override
  Widget build(BuildContext context) {
    final isDark = ref.watch(darkModeProvider);

    if (!_loaded) {
      return const Center(child: CircularProgressIndicator());
    }

    final content = ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (widget.embedded)
          const Padding(
            padding: EdgeInsets.only(bottom: 12),
            child: Align(
              alignment: Alignment.centerRight,
              child: Text('الإعدادات', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            ),
          ),

        // Shop name
        Card(
          child: ListTile(
            leading: const Icon(Icons.storefront),
            title: const Text('اسم المحل'),
            subtitle: Text(_shopName),
            onTap: () => _editShopName(context),
          ),
        ),

        // Dark mode
        Card(
          child: SwitchListTile(
            secondary: const Icon(Icons.dark_mode),
            title: const Text('الوضع الليلي'),
            value: isDark,
            onChanged: (val) async {
              ref.read(darkModeProvider.notifier).state = val;
              await ref.read(settingsRepositoryProvider).setValue('dark_mode', val ? '1' : '0');
            },
          ),
        ),

        const SizedBox(height: 8),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 8),
          child: Align(alignment: Alignment.centerRight, child: Text('التنبيهات', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
        ),

        // Debt threshold
        Card(
          child: ListTile(
            leading: const Icon(Icons.warning_amber),
            title: const Text('حد التنبيه عند الدين'),
            subtitle: Text('سيتم التنبيه عند تجاوز ${_debtThreshold.toStringAsFixed(0)} جنيه'),
            onTap: () => _editDebtThreshold(context),
          ),
        ),

        // Late payment days
        Card(
          child: ListTile(
            leading: const Icon(Icons.schedule),
            title: const Text('مدة التأخر في السداد'),
            subtitle: Text('تنبيه بعد $_latePaymentDays يوم بدون دفعة'),
            onTap: () => _editLatePaymentDays(context),
          ),
        ),

        const SizedBox(height: 8),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 8),
          child: Align(alignment: Alignment.centerRight, child: Text('النسخ الاحتياطي', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
        ),

        Card(
          child: ListTile(
            leading: const Icon(Icons.backup),
            title: const Text('تصدير نسخة احتياطية'),
            subtitle: const Text('حفظ نسخة من قاعدة البيانات'),
            trailing: _busy ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)) : null,
            onTap: _busy ? null : () => _exportBackup(context),
          ),
        ),
        Card(
          child: ListTile(
            leading: const Icon(Icons.restore_page),
            title: const Text('استيراد نسخة احتياطية'),
            subtitle: const Text('استعادة البيانات من ملف'),
            onTap: _busy ? null : () => _importBackup(context),
          ),
        ),
        Card(
          child: ListTile(
            leading: const Icon(Icons.cloud_upload_outlined),
            title: const Text('Google Drive'),
            subtitle: const Text('سيتم إضافة هذه الميزة في تحديث مستقبلي'),
            enabled: false,
          ),
        ),

        const SizedBox(height: 24),
        Center(
          child: Text(
            'إدارة الديون - إصدار 1.0.0',
            style: TextStyle(color: Theme.of(context).textTheme.bodySmall?.color, fontSize: 12),
          ),
        ),
        const SizedBox(height: 80),
      ],
    );

    if (widget.embedded) return content;

    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: content,
    );
  }

  Future<void> _editShopName(BuildContext context) async {
    final controller = TextEditingController(text: _shopName);
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('اسم المحل'),
        content: TextField(controller: controller, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          ElevatedButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('حفظ')),
        ],
      ),
    );
    if (result != null && result.trim().isNotEmpty) {
      await ref.read(settingsRepositoryProvider).setValue('shop_name', result.trim());
      setState(() => _shopName = result.trim());
    }
  }

  Future<void> _editDebtThreshold(BuildContext context) async {
    final controller = TextEditingController(text: _debtThreshold.toStringAsFixed(0));
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حد التنبيه عند الدين'),
        content: TextField(
          controller: controller,
          autofocus: true,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(suffixText: 'جنيه'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          ElevatedButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('حفظ')),
        ],
      ),
    );
    if (result != null) {
      final value = double.tryParse(result);
      if (value != null && value > 0) {
        await ref.read(settingsRepositoryProvider).setValue('debt_alert_threshold', value.toString());
        setState(() => _debtThreshold = value);
      }
    }
  }

  Future<void> _editLatePaymentDays(BuildContext context) async {
    final controller = TextEditingController(text: _latePaymentDays.toString());
    final result = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('مدة التأخر في السداد'),
        content: TextField(
          controller: controller,
          autofocus: true,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(suffixText: 'يوم'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          ElevatedButton(onPressed: () => Navigator.pop(context, controller.text), child: const Text('حفظ')),
        ],
      ),
    );
    if (result != null) {
      final value = int.tryParse(result);
      if (value != null && value > 0) {
        await ref.read(settingsRepositoryProvider).setValue('late_payment_days', value.toString());
        setState(() => _latePaymentDays = value);
      }
    }
  }

  Future<void> _exportBackup(BuildContext context) async {
    setState(() => _busy = true);
    try {
      final path = await BackupService.exportBackup();
      if (!context.mounted) return;
      await showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('تم إنشاء النسخة الاحتياطية'),
          content: Text('تم حفظ الملف في:\n$path'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('إغلاق')),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                BackupService.shareBackup(path);
              },
              child: const Text('مشاركة'),
            ),
          ],
        ),
      );
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('خطأ: $e')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _importBackup(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('استيراد نسخة احتياطية'),
        content: const Text('سيتم استبدال جميع البيانات الحالية بالنسخة المختارة. هل تريد الاستمرار؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          ElevatedButton(onPressed: () => Navigator.pop(context, true), child: const Text('استمرار')),
        ],
      ),
    );
    if (confirm != true) return;

    setState(() => _busy = true);
    try {
      final success = await BackupService.importBackup();
      if (success) {
        ref.read(dataRefreshProvider.notifier).state++;
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('تم استيراد النسخة الاحتياطية بنجاح')),
          );
        }
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('خطأ: $e')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }
}
