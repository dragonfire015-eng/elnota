import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../repositories/customer_repository.dart';
import '../repositories/product_repository.dart';
import '../repositories/sale_repository.dart';
import '../repositories/payment_repository.dart';
import '../repositories/settings_repository.dart';
import '../services/speech_service.dart';

final customerRepositoryProvider = Provider<CustomerRepository>((ref) => CustomerRepository());
final productRepositoryProvider = Provider<ProductRepository>((ref) => ProductRepository());
final saleRepositoryProvider = Provider<SaleRepository>((ref) => SaleRepository());
final paymentRepositoryProvider = Provider<PaymentRepository>((ref) => PaymentRepository());
final settingsRepositoryProvider = Provider<SettingsRepository>((ref) => SettingsRepository());

final speechServiceProvider = Provider<SpeechService>((ref) => SpeechService());

/// Bumped whenever data changes, to trigger re-fetches across the app.
final dataRefreshProvider = StateProvider<int>((ref) => 0);
