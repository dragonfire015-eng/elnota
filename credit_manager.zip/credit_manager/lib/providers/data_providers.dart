import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/customer.dart';
import '../models/product.dart';
import '../models/payment.dart';
import 'repository_providers.dart';

/// All customers (no balances) - for pickers etc.
final allCustomersProvider = FutureProvider<List<Customer>>((ref) async {
  ref.watch(dataRefreshProvider);
  final repo = ref.watch(customerRepositoryProvider);
  return repo.getAllCustomers();
});

/// All customers with computed balances - for the customer list screen
final customersWithBalancesProvider = FutureProvider<List<CustomerWithBalance>>((ref) async {
  ref.watch(dataRefreshProvider);
  final repo = ref.watch(customerRepositoryProvider);
  return repo.getAllCustomersWithBalances();
});

/// Single customer with balance
final customerBalanceProvider = FutureProvider.family<CustomerWithBalance, int>((ref, customerId) async {
  ref.watch(dataRefreshProvider);
  final repo = ref.watch(customerRepositoryProvider);
  final customer = await repo.getCustomerById(customerId);
  if (customer == null) {
    throw Exception('العميل غير موجود');
  }
  return repo.getCustomerWithBalance(customer);
});

/// All products
final allProductsProvider = FutureProvider<List<Product>>((ref) async {
  ref.watch(dataRefreshProvider);
  final repo = ref.watch(productRepositoryProvider);
  return repo.getAllProducts();
});

/// Customer search query state
final customerSearchQueryProvider = StateProvider<String>((ref) => '');

/// Filtered customer suggestions based on search query
final customerSuggestionsProvider = FutureProvider<List<Customer>>((ref) async {
  final query = ref.watch(customerSearchQueryProvider);
  ref.watch(dataRefreshProvider);
  final repo = ref.watch(customerRepositoryProvider);
  if (query.isEmpty) {
    return repo.getAllCustomers();
  }
  return repo.searchCustomers(query);
});

/// Combined transactions (sales + payments) for a customer, sorted by date desc
final customerTransactionsProvider = FutureProvider.family<List<Transaction>, int>((ref, customerId) async {
  ref.watch(dataRefreshProvider);
  final saleRepo = ref.watch(saleRepositoryProvider);
  final paymentRepo = ref.watch(paymentRepositoryProvider);

  final sales = await saleRepo.getSalesByCustomer(customerId, includeDeleted: true);
  final payments = await paymentRepo.getPaymentsByCustomer(customerId, includeDeleted: true);

  final transactions = <Transaction>[
    ...sales.map((s) => Transaction.fromSale(s)),
    ...payments.map((p) => Transaction.fromPayment(p)),
  ];

  transactions.sort((a, b) => b.date.compareTo(a.date));
  return transactions;
});

/// Dashboard stats for home screen
class DashboardStats {
  final double totalDebts;
  final int customerCount;
  final double monthSales;
  final double monthPayments;
  final List<Transaction> recentTransactions;
  final List<CustomerWithBalance> topDebtors;
  final List<CustomerWithBalance> latePayers;

  DashboardStats({
    required this.totalDebts,
    required this.customerCount,
    required this.monthSales,
    required this.monthPayments,
    required this.recentTransactions,
    required this.topDebtors,
    required this.latePayers,
  });
}

final dashboardStatsProvider = FutureProvider<DashboardStats>((ref) async {
  ref.watch(dataRefreshProvider);

  final customerRepo = ref.watch(customerRepositoryProvider);
  final saleRepo = ref.watch(saleRepositoryProvider);
  final paymentRepo = ref.watch(paymentRepositoryProvider);
  final settingsRepo = ref.watch(settingsRepositoryProvider);

  final totalDebts = await customerRepo.getTotalDebts();
  final customerCount = await customerRepo.getCustomerCount();
  final monthSales = await saleRepo.getMonthSalesTotal();
  final monthPayments = await paymentRepo.getMonthPaymentsTotal();
  final topDebtors = await customerRepo.getTopDebtors(limit: 5);

  final latePaymentDays = await settingsRepo.getLatePaymentDays();
  final latePayers = await customerRepo.getLatePaymentCustomers(latePaymentDays);

  final recentSales = await saleRepo.getRecentSales(limit: 10);
  final recentPayments = await paymentRepo.getRecentPayments(limit: 10);

  final recentTransactions = <Transaction>[
    ...recentSales.map((s) => Transaction.fromSale(s)),
    ...recentPayments.map((p) => Transaction.fromPayment(p)),
  ];
  recentTransactions.sort((a, b) => b.date.compareTo(a.date));

  return DashboardStats(
    totalDebts: totalDebts,
    customerCount: customerCount,
    monthSales: monthSales,
    monthPayments: monthPayments,
    recentTransactions: recentTransactions.take(10).toList(),
    topDebtors: topDebtors,
    latePayers: latePayers,
  );
});

/// Dark mode toggle
final darkModeProvider = StateProvider<bool>((ref) => false);
