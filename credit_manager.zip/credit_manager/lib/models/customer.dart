class Customer {
  final int? id;
  final String name;
  final String? phone;
  final String? notes;
  final double debtLimit; // 0 = no limit
  final DateTime createdAt;

  Customer({
    this.id,
    required this.name,
    this.phone,
    this.notes,
    this.debtLimit = 0,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'phone': phone,
      'notes': notes,
      'debt_limit': debtLimit,
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory Customer.fromMap(Map<String, dynamic> map) {
    return Customer(
      id: map['id'] as int?,
      name: map['name'] as String,
      phone: map['phone'] as String?,
      notes: map['notes'] as String?,
      debtLimit: (map['debt_limit'] as num?)?.toDouble() ?? 0,
      createdAt: DateTime.parse(map['created_at'] as String),
    );
  }

  Customer copyWith({
    int? id,
    String? name,
    String? phone,
    String? notes,
    double? debtLimit,
    DateTime? createdAt,
  }) {
    return Customer(
      id: id ?? this.id,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      notes: notes ?? this.notes,
      debtLimit: debtLimit ?? this.debtLimit,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}

/// Used for "أكثر العملاء مديونية" and balance display
class CustomerWithBalance {
  final Customer customer;
  final double totalPurchases;
  final double totalPayments;

  CustomerWithBalance({
    required this.customer,
    required this.totalPurchases,
    required this.totalPayments,
  });

  double get balance => totalPurchases - totalPayments;
}
