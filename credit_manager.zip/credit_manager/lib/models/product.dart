class Product {
  final int? id;
  final String name;
  final double price;
  final List<String> aliases; // synonyms for voice recognition, stored as JSON-joined string
  final DateTime createdAt;

  Product({
    this.id,
    required this.name,
    required this.price,
    this.aliases = const [],
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'price': price,
      'aliases': aliases.join('|'),
      'created_at': createdAt.toIso8601String(),
    };
  }

  factory Product.fromMap(Map<String, dynamic> map) {
    final aliasesStr = map['aliases'] as String?;
    return Product(
      id: map['id'] as int?,
      name: map['name'] as String,
      price: (map['price'] as num).toDouble(),
      aliases: (aliasesStr == null || aliasesStr.isEmpty)
          ? []
          : aliasesStr.split('|'),
      createdAt: DateTime.parse(map['created_at'] as String),
    );
  }

  Product copyWith({
    int? id,
    String? name,
    double? price,
    List<String>? aliases,
    DateTime? createdAt,
  }) {
    return Product(
      id: id ?? this.id,
      name: name ?? this.name,
      price: price ?? this.price,
      aliases: aliases ?? this.aliases,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}
