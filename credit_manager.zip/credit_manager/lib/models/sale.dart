class Sale {
  final int? id;
  final int customerId;
  final int? productId;
  final String productName; // snapshot of product name at time of sale
  final double quantity;
  final double unitPrice;
  final double total;
  final DateTime date;
  final String? note;
  final bool isDeleted; // soft delete for "استرجاع"

  Sale({
    this.id,
    required this.customerId,
    this.productId,
    required this.productName,
    required this.quantity,
    required this.unitPrice,
    required this.total,
    DateTime? date,
    this.note,
    this.isDeleted = false,
  }) : date = date ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customer_id': customerId,
      'product_id': productId,
      'product_name': productName,
      'quantity': quantity,
      'unit_price': unitPrice,
      'total': total,
      'date': date.toIso8601String(),
      'note': note,
      'is_deleted': isDeleted ? 1 : 0,
    };
  }

  factory Sale.fromMap(Map<String, dynamic> map) {
    return Sale(
      id: map['id'] as int?,
      customerId: map['customer_id'] as int,
      productId: map['product_id'] as int?,
      productName: map['product_name'] as String,
      quantity: (map['quantity'] as num).toDouble(),
      unitPrice: (map['unit_price'] as num).toDouble(),
      total: (map['total'] as num).toDouble(),
      date: DateTime.parse(map['date'] as String),
      note: map['note'] as String?,
      isDeleted: (map['is_deleted'] as int? ?? 0) == 1,
    );
  }

  Sale copyWith({
    int? id,
    int? customerId,
    int? productId,
    String? productName,
    double? quantity,
    double? unitPrice,
    double? total,
    DateTime? date,
    String? note,
    bool? isDeleted,
  }) {
    return Sale(
      id: id ?? this.id,
      customerId: customerId ?? this.customerId,
      productId: productId ?? this.productId,
      productName: productName ?? this.productName,
      quantity: quantity ?? this.quantity,
      unitPrice: unitPrice ?? this.unitPrice,
      total: total ?? this.total,
      date: date ?? this.date,
      note: note ?? this.note,
      isDeleted: isDeleted ?? this.isDeleted,
    );
  }
}
