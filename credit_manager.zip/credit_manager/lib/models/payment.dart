class Payment {
  final int? id;
  final int customerId;
  final double amount;
  final DateTime date;
  final String? note;
  final bool isDeleted;

  Payment({
    this.id,
    required this.customerId,
    required this.amount,
    DateTime? date,
    this.note,
    this.isDeleted = false,
  }) : date = date ?? DateTime.now();

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customer_id': customerId,
      'amount': amount,
      'date': date.toIso8601String(),
      'note': note,
      'is_deleted': isDeleted ? 1 : 0,
    };
  }

  factory Payment.fromMap(Map<String, dynamic> map) {
    return Payment(
      id: map['id'] as int?,
      customerId: map['customer_id'] as int,
      amount: (map['amount'] as num).toDouble(),
      date: DateTime.parse(map['date'] as String),
      note: map['note'] as String?,
      isDeleted: (map['is_deleted'] as int? ?? 0) == 1,
    );
  }

  Payment copyWith({
    int? id,
    int? customerId,
    double? amount,
    DateTime? date,
    String? note,
    bool? isDeleted,
  }) {
    return Payment(
      id: id ?? this.id,
      customerId: customerId ?? this.customerId,
      amount: amount ?? this.amount,
      date: date ?? this.date,
      note: note ?? this.note,
      isDeleted: isDeleted ?? this.isDeleted,
    );
  }
}

/// Unified transaction type for displaying combined sales+payments in statement
enum TransactionType { sale, payment }

class Transaction {
  final TransactionType type;
  final int id;
  final int customerId;
  final String description;
  final double amount; // positive value
  final DateTime date;
  final bool isDeleted;
  final String? extraInfo; // e.g. quantity x price for sales

  Transaction({
    required this.type,
    required this.id,
    required this.customerId,
    required this.description,
    required this.amount,
    required this.date,
    this.isDeleted = false,
    this.extraInfo,
  });

  factory Transaction.fromSale(Sale sale) {
    return Transaction(
      type: TransactionType.sale,
      id: sale.id!,
      customerId: sale.customerId,
      description: sale.productName,
      amount: sale.total,
      date: sale.date,
      isDeleted: sale.isDeleted,
      extraInfo: '${sale.quantity} × ${sale.unitPrice.toStringAsFixed(0)}',
    );
  }

  factory Transaction.fromPayment(Payment payment) {
    return Transaction(
      type: TransactionType.payment,
      id: payment.id!,
      customerId: payment.customerId,
      description: 'دفعة',
      amount: payment.amount,
      date: payment.date,
      isDeleted: payment.isDeleted,
    );
  }
}
