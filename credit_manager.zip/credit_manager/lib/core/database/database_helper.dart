import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._internal();
  static Database? _database;

  DatabaseHelper._internal();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    final dbPath = await getDatabasePath();
    return await openDatabase(
      dbPath,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<String> getDatabasePath() async {
    final dbDir = await getDatabasesPath();
    return join(dbDir, 'credit_manager.db');
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT,
        notes TEXT,
        debt_limit REAL NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        price REAL NOT NULL,
        aliases TEXT,
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE sales (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        product_id INTEGER,
        product_name TEXT NOT NULL,
        quantity REAL NOT NULL,
        unit_price REAL NOT NULL,
        total REAL NOT NULL,
        date TEXT NOT NULL,
        note TEXT,
        is_deleted INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE CASCADE,
        FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE SET NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        date TEXT NOT NULL,
        note TEXT,
        is_deleted INTEGER NOT NULL DEFAULT 0,
        FOREIGN KEY (customer_id) REFERENCES customers (id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE settings (
        key TEXT PRIMARY KEY,
        value TEXT
      )
    ''');

    await db.execute('CREATE INDEX idx_sales_customer ON sales (customer_id)');
    await db.execute('CREATE INDEX idx_sales_date ON sales (date)');
    await db.execute('CREATE INDEX idx_payments_customer ON payments (customer_id)');
    await db.execute('CREATE INDEX idx_payments_date ON payments (date)');

    // Seed common products
    final now = DateTime.now().toIso8601String();
    await db.insert('products', {
      'name': 'علبة سجائر',
      'price': 50,
      'aliases': 'سجائر|علبة دخان|دخان',
      'created_at': now,
    });
    await db.insert('products', {
      'name': 'مياه غازية',
      'price': 20,
      'aliases': 'كولا|بيبسي|سبرايت|غازي|غازية',
      'created_at': now,
    });
    await db.insert('products', {
      'name': 'شيبسي',
      'price': 15,
      'aliases': 'شيبس|بطاطس',
      'created_at': now,
    });

    await db.insert('settings', {'key': 'debt_alert_threshold', 'value': '500'});
    await db.insert('settings', {'key': 'late_payment_days', 'value': '30'});
    await db.insert('settings', {'key': 'dark_mode', 'value': '0'});
    await db.insert('settings', {'key': 'shop_name', 'value': 'محلي'});
  }

  Future<void> close() async {
    final db = _database;
    if (db != null) {
      await db.close();
      _database = null;
    }
  }
}
