import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/theme/app_theme.dart';
import '../models/customer.dart';
import '../models/product.dart';
import '../models/sale.dart';
import '../models/payment.dart';
import '../providers/data_providers.dart';
import '../providers/repository_providers.dart';
import '../services/voice_command_parser.dart';

/// Shows the voice listening dialog, processes the result, and shows
/// a confirmation dialog before saving. Call this from a button's onPressed.
Future<void> showVoiceCommandDialog(BuildContext context, WidgetRef ref) async {
  final speechService = ref.read(speechServiceProvider);

  final available = await speechService.initialize();
  if (!available) {
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تعذر الوصول إلى الميكروفون. تأكد من إعطاء الإذن.')),
      );
    }
    return;
  }

  if (!context.mounted) return;

  final recognizedText = await showModalBottomSheet<String>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (context) => const _VoiceListeningSheet(),
  );

  if (recognizedText == null || recognizedText.trim().isEmpty) return;
  if (!context.mounted) return;

  await _processVoiceCommand(context, ref, recognizedText);
}

Future<void> _processVoiceCommand(BuildContext context, WidgetRef ref, String text) async {
  final customers = await ref.read(allCustomersProvider.future);
  final products = await ref.read(allProductsProvider.future);

  final result = VoiceCommandParser.parse(text, customers, products);

  if (!context.mounted) return;

  await showDialog(
    context: context,
    builder: (context) => _VoiceConfirmationDialog(result: result, products: products, customers: customers),
  );
}

/// --- Listening Bottom Sheet ---

class _VoiceListeningSheet extends ConsumerStatefulWidget {
  const _VoiceListeningSheet();

  @override
  ConsumerState<_VoiceListeningSheet> createState() => _VoiceListeningSheetState();
}

class _VoiceListeningSheetState extends ConsumerState<_VoiceListeningSheet> {
  String _partialText = '';
  bool _isListening = false;
  bool _done = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _start());
  }

  Future<void> _start() async {
    final speechService = ref.read(speechServiceProvider);
    setState(() => _isListening = true);

    await speechService.startListening(
      onPartialResult: (text) {
        if (mounted) setState(() => _partialText = text);
      },
      onResult: (text) {
        if (mounted) {
          setState(() {
            _partialText = text;
            _isListening = false;
            _done = true;
          });
          Future.delayed(const Duration(milliseconds: 400), () {
            if (mounted) Navigator.of(context).pop(text);
          });
        }
      },
    );
  }

  Future<void> _stopAndConfirm() async {
    final speechService = ref.read(speechServiceProvider);
    await speechService.stopListening();
    if (mounted) Navigator.of(context).pop(_partialText);
  }

  @override
  void dispose() {
    ref.read(speechServiceProvider).cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 30, 20, 40),
      decoration: BoxDecoration(
        color: Theme.of(context).scaffoldBackgroundColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 100,
            height: 100,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _isListening
                  ? AppTheme.primaryColor.withOpacity(0.15)
                  : Colors.grey.withOpacity(0.15),
            ),
            child: Icon(
              _isListening ? Icons.mic : Icons.mic_none,
              size: 50,
              color: _isListening ? AppTheme.primaryColor : Colors.grey,
            ),
          ),
          const SizedBox(height: 20),
          Text(
            _isListening ? 'جاري الاستماع...' : 'اضغط للتحدث',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            constraints: const BoxConstraints(minHeight: 60),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              _partialText.isEmpty ? 'مثال: أحمد أخذ علبة سجائر' : _partialText,
              style: TextStyle(
                fontSize: 16,
                color: _partialText.isEmpty
                    ? Theme.of(context).textTheme.bodySmall?.color
                    : null,
              ),
              textAlign: TextAlign.center,
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('إلغاء'),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: ElevatedButton(
                  onPressed: _isListening ? _stopAndConfirm : null,
                  child: const Text('تم'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// --- Confirmation Dialog ---

class _VoiceConfirmationDialog extends ConsumerStatefulWidget {
  final VoiceCommandResult result;
  final List<Product> products;
  final List<Customer> customers;

  const _VoiceConfirmationDialog({
    required this.result,
    required this.products,
    required this.customers,
  });

  @override
  ConsumerState<_VoiceConfirmationDialog> createState() => _VoiceConfirmationDialogState();
}

class _VoiceConfirmationDialogState extends ConsumerState<_VoiceConfirmationDialog> {
  Customer? _selectedCustomer;
  Product? _selectedProduct;
  late TextEditingController _quantityController;
  late TextEditingController _amountController;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final r = widget.result;
    _selectedCustomer = r.customer ?? (r.ambiguousCustomers?.isNotEmpty == true ? null : null);
    _selectedProduct = r.product;
    _quantityController = TextEditingController(text: r.quantity.toString());
    _amountController = TextEditingController(text: (r.paymentAmount ?? 0).toString());
  }

  @override
  void dispose() {
    _quantityController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  bool get _isPayment => widget.result.type == VoiceCommandType.payment;
  bool get _isSale => widget.result.type == VoiceCommandType.sale;

  Future<void> _save() async {
    if (_selectedCustomer == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('يجب اختيار العميل')),
      );
      return;
    }

    setState(() => _saving = true);

    try {
      if (_isPayment) {
        final amount = double.tryParse(_amountController.text) ?? 0;
        if (amount <= 0) {
          throw Exception('المبلغ غير صحيح');
        }
        final paymentRepo = ref.read(paymentRepositoryProvider);
        await paymentRepo.insertPayment(Payment(
          customerId: _selectedCustomer!.id!,
          amount: amount,
        ));
      } else {
        if (_selectedProduct == null) {
          throw Exception('يجب اختيار المنتج');
        }
        final quantity = double.tryParse(_quantityController.text) ?? 1;
        if (quantity <= 0) {
          throw Exception('الكمية غير صحيحة');
        }
        final saleRepo = ref.read(saleRepositoryProvider);
        await saleRepo.insertSale(Sale(
          customerId: _selectedCustomer!.id!,
          productId: _selectedProduct!.id,
          productName: _selectedProduct!.name,
          quantity: quantity,
          unitPrice: _selectedProduct!.price,
          total: _selectedProduct!.price * quantity,
        ));
      }

      ref.read(dataRefreshProvider.notifier).state++;

      if (mounted) {
        Navigator.of(context).pop();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(_isPayment ? '✅ تم تسجيل الدفعة بنجاح' : '✅ تم تسجيل عملية البيع بنجاح'),
            backgroundColor: AppTheme.successColor,
          ),
        );
      }
    } catch (e) {
      setState(() => _saving = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('خطأ: ${e.toString().replaceAll('Exception: ', '')}')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final r = widget.result;
    final candidateCustomers = r.ambiguousCustomers ?? widget.customers;

    return AlertDialog(
      title: Row(
        children: [
          Icon(
            _isPayment ? Icons.payments : Icons.shopping_cart,
            color: _isPayment ? AppTheme.successColor : AppTheme.errorColor,
          ),
          const SizedBox(width: 8),
          Text(_isPayment ? 'تأكيد دفعة' : 'تأكيد عملية بيع'),
        ],
      ),
      content: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(10),
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text('"${r.rawText}"', style: const TextStyle(fontStyle: FontStyle.italic)),
            ),

            if (r.error != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Text(r.error!, style: const TextStyle(color: AppTheme.errorColor, fontSize: 13)),
              ),

            // Customer selector
            const Text('العميل', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            DropdownButtonFormField<Customer>(
              initialValue: _selectedCustomer,
              hint: const Text('اختر العميل'),
              isExpanded: true,
              items: candidateCustomers.map((c) {
                return DropdownMenuItem(value: c, child: Text(c.name));
              }).toList(),
              onChanged: (val) => setState(() => _selectedCustomer = val),
            ),
            const SizedBox(height: 16),

            if (_isSale) ...[
              const Text('المنتج', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              DropdownButtonFormField<Product>(
                initialValue: _selectedProduct,
                hint: const Text('اختر المنتج'),
                isExpanded: true,
                items: widget.products.map((p) {
                  return DropdownMenuItem(
                    value: p,
                    child: Text('${p.name} (${p.price.toStringAsFixed(0)} ج)'),
                  );
                }).toList(),
                onChanged: (val) => setState(() => _selectedProduct = val),
              ),
              const SizedBox(height: 16),
              const Text('الكمية', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              TextField(
                controller: _quantityController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(border: OutlineInputBorder()),
              ),
              if (_selectedProduct != null) ...[
                const SizedBox(height: 12),
                Builder(builder: (context) {
                  final qty = double.tryParse(_quantityController.text) ?? 1;
                  final total = qty * _selectedProduct!.price;
                  return Text(
                    'الإجمالي: ${total.toStringAsFixed(2)} جنيه',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  );
                }),
              ],
            ] else ...[
              const Text('المبلغ المدفوع', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              TextField(
                controller: _amountController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(border: OutlineInputBorder(), suffixText: 'جنيه'),
              ),
            ],
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: _saving ? null : () => Navigator.of(context).pop(),
          child: const Text('إلغاء'),
        ),
        ElevatedButton(
          onPressed: _saving ? null : _save,
          style: ElevatedButton.styleFrom(minimumSize: const Size(100, 44)),
          child: _saving
              ? const SizedBox(
                  width: 20, height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : const Text('حفظ'),
        ),
      ],
    );
  }
}
