import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../core/theme/app_theme.dart';
import '../models/payment.dart';

class StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final Color color;

  const StatCard({
    super.key,
    required this.title,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: color, size: 26),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: TextStyle(color: Theme.of(context).textTheme.bodySmall?.color, fontSize: 13)),
                  const SizedBox(height: 4),
                  Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TransactionTile extends StatelessWidget {
  final Transaction transaction;
  final String? customerName;
  final VoidCallback? onTap;
  final VoidCallback? onDelete;
  final VoidCallback? onRestore;

  const TransactionTile({
    super.key,
    required this.transaction,
    this.customerName,
    this.onTap,
    this.onDelete,
    this.onRestore,
  });

  @override
  Widget build(BuildContext context) {
    final isSale = transaction.type == TransactionType.sale;
    final dateFormat = DateFormat('yyyy/MM/dd – HH:mm');
    final amountColor = isSale ? AppTheme.errorColor : AppTheme.successColor;

    return Opacity(
      opacity: transaction.isDeleted ? 0.5 : 1,
      child: ListTile(
        onTap: onTap,
        leading: CircleAvatar(
          backgroundColor: amountColor.withOpacity(0.15),
          child: Icon(
            isSale ? Icons.shopping_cart : Icons.payments,
            color: amountColor,
            size: 20,
          ),
        ),
        title: Text(
          customerName != null ? '$customerName - ${transaction.description}' : transaction.description,
          style: TextStyle(
            decoration: transaction.isDeleted ? TextDecoration.lineThrough : null,
          ),
        ),
        subtitle: Text(
          transaction.extraInfo != null
              ? '${transaction.extraInfo} • ${dateFormat.format(transaction.date)}'
              : dateFormat.format(transaction.date),
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              '${isSale ? '+' : '-'}${transaction.amount.toStringAsFixed(0)} ج',
              style: TextStyle(fontWeight: FontWeight.bold, color: amountColor),
            ),
            if (transaction.isDeleted && onRestore != null)
              IconButton(
                icon: const Icon(Icons.restore, size: 20),
                onPressed: onRestore,
                tooltip: 'استرجاع',
              )
            else if (onDelete != null)
              IconButton(
                icon: const Icon(Icons.delete_outline, size: 20),
                onPressed: onDelete,
                tooltip: 'حذف',
              ),
          ],
        ),
      ),
    );
  }
}
