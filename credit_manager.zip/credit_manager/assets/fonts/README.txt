ضع ملفات الخطوط العربية هنا لتفعيل عرض النصوص العربية بشكل صحيح في ملفات PDF:

- NotoSansArabic-Regular.ttf
- NotoSansArabic-Bold.ttf

يمكن تحميلها من Google Fonts:
https://fonts.google.com/noto/specimen/Noto+Sans+Arabic

بدون هذه الملفات، سيتم استخدام خط افتراضي قد لا يدعم عرض النص العربي بشكل صحيح في ملفات PDF.
الواجهة الرئيسية للتطبيق (الشاشات) لا تحتاج لهذه الملفات وتعمل بشكل طبيعي باستخدام خط النظام.
